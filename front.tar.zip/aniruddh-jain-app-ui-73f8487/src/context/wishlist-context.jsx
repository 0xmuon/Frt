import { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";
const STORAGE_KEY = "swiftshop.wishlist";
const WishlistContext = createContext(null);
export function WishlistProvider({ children }) {
    const [ids, setIds] = useState([]);
    const [ready, setReady] = useState(false);
    useEffect(() => {
        const raw = window.localStorage.getItem(STORAGE_KEY);
        let next = [];
        if (raw) {
            try {
                const parsed = JSON.parse(raw);
                if (Array.isArray(parsed)) {
                    next = parsed.filter((id) => typeof id === "number");
                }
            }
            catch {
                next = [];
            }
        }
        queueMicrotask(() => {
            setIds(next);
            setReady(true);
        });
    }, []);
    useEffect(() => {
        if (ready) {
            window.localStorage.setItem(STORAGE_KEY, JSON.stringify(ids));
        }
    }, [ids, ready]);
    const has = useCallback((productId) => ids.includes(productId), [ids]);
    const toggle = useCallback((productId) => {
        setIds((current) => current.includes(productId) ? current.filter((id) => id !== productId) : [...current, productId]);
    }, []);
    const value = useMemo(() => ({ ids, ready, has, toggle }), [ids, ready, has, toggle]);
    return <WishlistContext.Provider value={value}>{children}</WishlistContext.Provider>;
}
export function useWishlist() {
    const context = useContext(WishlistContext);
    if (!context) {
        throw new Error("useWishlist must be used within WishlistProvider");
    }
    return context;
}
