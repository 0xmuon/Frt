import { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";
import { shopApi } from "@/services/shop-api";
import { readToken } from "@/services/session";
import { useAuth } from "@/context/auth-context";
const EMPTY_CART = {
    items: [],
    itemCount: 0,
    subtotal: 0,
    shipping: 0,
    total: 0,
};
const CartContext = createContext(null);
export function CartProvider({ children }) {
    const { user, status: authStatus } = useAuth();
    const userId = user?.id ?? null;
    const [snapshot, setSnapshot] = useState(null);
    useEffect(() => {
        if (authStatus !== "ready") {
            return;
        }
        let cancelled = false;
        const load = userId ? shopApi.getCart() : shopApi.getGuestCart();
        load
            .then((cart) => {
            if (!cancelled) {
                setSnapshot({ userId, cart });
            }
        })
            .catch(() => {
            if (!cancelled) {
                setSnapshot({ userId, cart: EMPTY_CART });
            }
        });
        return () => {
            cancelled = true;
        };
    }, [authStatus, userId]);
    const status = authStatus === "ready" && snapshot?.userId === userId ? "ready" : "loading";
    const cart = snapshot?.userId === userId ? snapshot.cart : EMPTY_CART;
    const addItem = useCallback(async (productId, quantity = 1) => {
        // A stored token means the shopper is signed in, even if the profile
        // request has not finished yet. Writing the guest cart in that window
        // would drop the line when the account cart loads.
        const authed = Boolean(readToken());
        const next = authed
            ? await shopApi.addToCart(productId, quantity)
            : await shopApi.addToGuestCart(productId, quantity);
        setSnapshot({ userId, cart: next });
    }, [userId]);
    const updateQuantity = useCallback(async (cartItemId, quantity) => {
        const authed = Boolean(readToken());
        const next = authed
            ? await shopApi.updateCartItem(cartItemId, quantity)
            : await shopApi.updateGuestCartItem(cartItemId, quantity);
        setSnapshot({ userId, cart: next });
    }, [userId]);
    const removeItem = useCallback(async (cartItemId) => {
        const authed = Boolean(readToken());
        const next = authed ? await shopApi.removeCartItem(cartItemId) : await shopApi.removeGuestCartItem(cartItemId);
        setSnapshot({ userId, cart: next });
    }, [userId]);
    const value = useMemo(() => ({ cart, status, addItem, updateQuantity, removeItem }), [cart, status, addItem, updateQuantity, removeItem]);
    return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
}
export function useCart() {
    const context = useContext(CartContext);
    if (!context) {
        throw new Error("useCart must be used within CartProvider");
    }
    return context;
}
