import { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";
import { shopApi } from "@/services/shop-api";
import { readToken } from "@/services/session";
const AuthContext = createContext(null);
async function adoptGuestCart() {
    const guest = shopApi.readGuestCart();
    if (guest.length === 0) {
        return;
    }
    await shopApi.mergeCart(guest);
    shopApi.clearGuestCart();
}
export function AuthProvider({ children }) {
    const [user, setUser] = useState(null);
    const [status, setStatus] = useState("loading");
    useEffect(() => {
        let cancelled = false;
        if (!readToken()) {
            queueMicrotask(() => {
                if (!cancelled) {
                    setStatus("ready");
                }
            });
            return () => {
                cancelled = true;
            };
        }
        shopApi
            .currentUser()
            .then((next) => {
            if (!cancelled) {
                setUser(next);
            }
        })
            .catch(() => {
            if (!cancelled) {
                setUser(null);
            }
        })
            .finally(() => {
            if (!cancelled) {
                setStatus("ready");
            }
        });
        return () => {
            cancelled = true;
        };
    }, []);
    const login = useCallback(async (input) => {
        const session = await shopApi.login(input);
        await adoptGuestCart();
        setUser(session.user);
    }, []);
    const register = useCallback(async (input) => {
        const session = await shopApi.register(input);
        await adoptGuestCart();
        setUser(session.user);
    }, []);
    const logout = useCallback(async () => {
        await shopApi.logout();
        setUser(null);
    }, []);
    const value = useMemo(() => ({ user, status, login, register, logout }), [user, status, login, register, logout]);
    return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}
export function useAuth() {
    const context = useContext(AuthContext);
    if (!context) {
        throw new Error("useAuth must be used within AuthProvider");
    }
    return context;
}
