import { HomePage as HomeView } from "@/components/home/home-page";
import { useDocumentTitle } from "@/hooks/useDocumentTitle";

export function HomePage() {
  useDocumentTitle("");
  return <HomeView />;
}
