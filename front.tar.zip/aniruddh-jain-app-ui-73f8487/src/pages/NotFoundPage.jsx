import { Link } from "react-router-dom";

import { buttonVariants } from "@/components/ui/button";
import { useDocumentTitle } from "@/hooks/useDocumentTitle";
import { cn } from "@/lib/utils";

export function NotFoundPage() {
  useDocumentTitle("Page not found");
  return (
    <div className="mx-auto max-w-lg py-16 text-center">
      <p className="text-xs tracking-[0.2em] text-copper uppercase">404</p>
      <h1 className="mt-2 text-4xl">That page is not on the floor.</h1>
      <p className="mt-3 text-muted-foreground">The link may be out of date. The shop is still open.</p>
      <Link to="/products" className={cn(buttonVariants({ size: "lg" }), "mt-6")}>
        Browse products
      </Link>
    </div>
  );
}
