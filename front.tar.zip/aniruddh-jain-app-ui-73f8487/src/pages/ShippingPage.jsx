import { ShippingPage as ShippingView } from "@/components/support/info-pages";
import { useDocumentTitle } from "@/hooks/useDocumentTitle";

export function ShippingPage() {
  useDocumentTitle("Shipping");
  return <ShippingView />;
}
