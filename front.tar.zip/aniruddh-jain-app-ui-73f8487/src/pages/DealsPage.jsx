import { ProductListing } from "@/components/products/product-listing";
import { useDocumentTitle } from "@/hooks/useDocumentTitle";

export function DealsPage() {
  useDocumentTitle("Deals");
  return (
    <ProductListing
      title="Deals"
      description="Marked-down pieces. The crossed-out price is what they were, the copper price is what they are."
      basePath="/deals"
      dealsOnly
    />
  );
}
