import { RegisterForm } from "@/components/auth/auth-forms";
import { useDocumentTitle } from "@/hooks/useDocumentTitle";

export function RegisterPage() {
  useDocumentTitle("Register");
  return <RegisterForm />;
}
