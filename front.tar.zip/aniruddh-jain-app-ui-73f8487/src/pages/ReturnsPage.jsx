import { ReturnsPage as ReturnsView } from "@/components/support/info-pages";
import { useDocumentTitle } from "@/hooks/useDocumentTitle";

export function ReturnsPage() {
  useDocumentTitle("Returns");
  return <ReturnsView />;
}
