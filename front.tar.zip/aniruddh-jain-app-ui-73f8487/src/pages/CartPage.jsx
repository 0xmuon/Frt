import { CartView } from "@/components/cart/cart-view";
import { useDocumentTitle } from "@/hooks/useDocumentTitle";

export function CartPage() {
  useDocumentTitle("Cart");
  return <CartView />;
}
