import { CategoriesIndex } from "@/components/products/category-view";
import { useDocumentTitle } from "@/hooks/useDocumentTitle";

export function CategoriesPage() {
  useDocumentTitle("Categories");
  return <CategoriesIndex />;
}
