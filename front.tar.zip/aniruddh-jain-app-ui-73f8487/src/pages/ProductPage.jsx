import { ProductDetail } from "@/components/products/product-detail";
import { useDocumentTitle } from "@/hooks/useDocumentTitle";

export function ProductPage() {
  useDocumentTitle("Product");
  return <ProductDetail />;
}
