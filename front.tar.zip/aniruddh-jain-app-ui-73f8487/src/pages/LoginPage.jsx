import { LoginForm } from "@/components/auth/auth-forms";
import { useDocumentTitle } from "@/hooks/useDocumentTitle";

export function LoginPage() {
  useDocumentTitle("Login");
  return <LoginForm />;
}
