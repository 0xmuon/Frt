import { CategoryView } from "@/components/products/category-view";
import { useDocumentTitle } from "@/hooks/useDocumentTitle";

export function CategoryPage() {
  useDocumentTitle("Category");
  return <CategoryView />;
}
