import { WishlistView } from "@/components/wishlist/wishlist-view";
import { useDocumentTitle } from "@/hooks/useDocumentTitle";

export function WishlistPage() {
  useDocumentTitle("Wishlist");
  return <WishlistView />;
}
