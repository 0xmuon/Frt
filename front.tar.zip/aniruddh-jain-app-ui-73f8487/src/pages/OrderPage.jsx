import { OrderDetailRoute } from "@/components/orders/order-history";
import { useDocumentTitle } from "@/hooks/useDocumentTitle";

export function OrderPage() {
  useDocumentTitle("Order");
  return <OrderDetailRoute />;
}
