import { ProductListing } from "@/components/products/product-listing";
import { useDocumentTitle } from "@/hooks/useDocumentTitle";

export function NewArrivalsPage() {
  useDocumentTitle("New Arrivals");
  return (
    <ProductListing
      title="New Arrivals"
      description="What just landed on the floor."
      basePath="/new-arrivals"
      arrivalsOnly
    />
  );
}
