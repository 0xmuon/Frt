import { HelpPage as HelpView } from "@/components/support/info-pages";
import { useDocumentTitle } from "@/hooks/useDocumentTitle";

export function HelpPage() {
  useDocumentTitle("Help Center");
  return <HelpView />;
}
