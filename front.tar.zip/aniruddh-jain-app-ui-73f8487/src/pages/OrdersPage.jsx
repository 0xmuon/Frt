import { OrderHistory } from "@/components/orders/order-history";
import { useDocumentTitle } from "@/hooks/useDocumentTitle";

export function OrdersPage() {
  useDocumentTitle("Order History");
  return <OrderHistory />;
}
