import { ProductListing } from "@/components/products/product-listing";
import { useDocumentTitle } from "@/hooks/useDocumentTitle";

export function ProductsPage() {
  useDocumentTitle("Shop");
  return (
    <ProductListing
      title="Shop"
      description="Every product on the floor. Search by name or category, then add what is in stock."
      basePath="/products"
    />
  );
}
