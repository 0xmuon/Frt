import { AccountView } from "@/components/account/account-view";
import { useDocumentTitle } from "@/hooks/useDocumentTitle";

export function AccountPage() {
  useDocumentTitle("Account");
  return <AccountView />;
}
