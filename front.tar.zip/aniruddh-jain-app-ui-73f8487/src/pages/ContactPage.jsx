import { ContactForm } from "@/components/support/contact-form";
import { useDocumentTitle } from "@/hooks/useDocumentTitle";

export function ContactPage() {
  useDocumentTitle("Contact Us");
  return <ContactForm />;
}
