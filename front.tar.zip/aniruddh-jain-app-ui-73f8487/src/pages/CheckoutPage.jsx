import { CheckoutView } from "@/components/checkout/checkout-view";
import { useDocumentTitle } from "@/hooks/useDocumentTitle";

export function CheckoutPage() {
  useDocumentTitle("Checkout");
  return <CheckoutView />;
}
