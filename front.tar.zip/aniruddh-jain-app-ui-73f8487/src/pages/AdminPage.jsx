import { AdminDesk } from "@/components/admin/admin-desk";
import { useDocumentTitle } from "@/hooks/useDocumentTitle";

export function AdminPage() {
  useDocumentTitle("Audit log");
  return <AdminDesk />;
}
