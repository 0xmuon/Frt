import { useEffect } from "react";

/** Browser tab title. Pass an empty string for the shop name alone. */
export function useDocumentTitle(title) {
  useEffect(() => {
    document.title = title ? `${title} · SwiftShop` : "SwiftShop";
  }, [title]);
}
