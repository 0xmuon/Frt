import { Link } from "react-router-dom";
import { useState } from "react";
import { toast } from "sonner";
import { PageHeader } from "@/components/common/page-header";
import { ProductImage } from "@/components/products/product-image";
import { buttonVariants } from "@/components/ui/button";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { useCart } from "@/context/cart-context";
import { formatItemCount, formatMoney } from "@/lib/format";
import { FREE_SHIPPING_AT } from "@/lib/pricing";
import { errorMessage } from "@/services/api-error";
import { cn } from "@/lib/utils";
export function CartSummary({ cart, children }) {
    return (<aside className="h-fit rounded-xl bg-card p-5 ring-1 ring-foreground/10">
      <h2 className="text-xl">Summary</h2>
      <dl className="mt-4 grid gap-2 text-sm">
        <div className="flex justify-between">
          <dt>Items</dt>
          <dd>{formatItemCount(cart.itemCount)}</dd>
        </div>
        <div className="flex justify-between">
          <dt>Subtotal</dt>
          <dd>{formatMoney(cart.subtotal)}</dd>
        </div>
        <div className="flex justify-between">
          <dt>Shipping</dt>
          <dd>{cart.shipping === 0 ? "Free" : formatMoney(cart.shipping)}</dd>
        </div>
        <div className="mt-2 flex justify-between border-t border-border pt-3 text-base font-medium">
          <dt>Total</dt>
          <dd>{formatMoney(cart.total)}</dd>
        </div>
      </dl>
      <p className="mt-3 text-xs text-muted-foreground">
        {cart.subtotal >= FREE_SHIPPING_AT || cart.subtotal === 0
            ? `Free shipping on orders of ${formatMoney(FREE_SHIPPING_AT)} or more.`
            : `Add ${formatMoney(FREE_SHIPPING_AT - cart.subtotal)} for free shipping.`}
      </p>
      {children}
    </aside>);
}
function QuantityControl({ item, onInvalid, }) {
    const { updateQuantity } = useCart();
    const [draft, setDraft] = useState(String(item.quantity));
    const [error, setError] = useState(null);
    const [pending, setPending] = useState(false);
    function report(message) {
        setError(message);
        onInvalid(item.product.id, message);
    }
    async function commit(raw) {
        if (!/^[1-9]\d*$/.test(raw)) {
            report("Quantity must be a positive integer.");
            return;
        }
        const quantity = Number(raw);
        if (quantity > item.product.stock) {
            report(`Only ${item.product.stock} available.`);
            return;
        }
        report(null);
        if (quantity === item.quantity) {
            return;
        }
        setPending(true);
        try {
            await updateQuantity(item.cartItemId, quantity);
        }
        catch (cause) {
            const message = errorMessage(cause, "Could not update the quantity.");
            report(message);
        }
        finally {
            setPending(false);
        }
    }
    return (<div className="grid gap-1">
      <Input aria-label={`Quantity for ${item.product.title}`} inputMode="numeric" value={draft} disabled={pending} aria-invalid={error != null} className="w-20" onChange={(event) => {
            const next = event.target.value;
            setDraft(next);
            if (!/^[1-9]\d*$/.test(next)) {
                report("Quantity must be a positive integer.");
                return;
            }
            const quantity = Number(next);
            if (quantity > item.product.stock) {
                report(`Only ${item.product.stock} available.`);
                return;
            }
            report(null);
            if (quantity !== item.quantity) {
                void commit(next);
            }
        }} onBlur={() => {
            void commit(draft);
        }}/>
      {error ? <p className="max-w-40 text-xs text-destructive">{error}</p> : null}
    </div>);
}
export function CartView() {
    const { cart, status, removeItem } = useCart();
    const [invalid, setInvalid] = useState({});
    const blocked = Object.keys(invalid).length > 0;
    const checkoutDisabled = cart.items.length === 0 || blocked || status !== "ready";
    function onInvalid(productId, message) {
        setInvalid((current) => {
            const next = { ...current };
            if (message) {
                next[productId] = message;
            }
            else {
                delete next[productId];
            }
            return next;
        });
    }
    async function remove(item) {
        onInvalid(item.product.id, null);
        try {
            await removeItem(item.cartItemId);
            toast.success(`Removed ${item.product.title}`);
        }
        catch (error) {
            toast.error(errorMessage(error, "Could not remove that item."));
        }
    }
    return (<div>
      <PageHeader title="Your Cart" description="Change quantities, take something out, or continue to checkout."/>
      {status !== "ready" ? (<Skeleton className="h-64 w-full rounded-xl"/>) : cart.items.length === 0 ? (<div className="rounded-xl border border-dashed border-border px-6 py-16 text-center">
          <p className="text-lg">Your cart is empty.</p>
          <Link to="/products" className={cn(buttonVariants(), "mt-4")}>
            Browse products
          </Link>
        </div>) : (<div className="grid items-start gap-8 lg:grid-cols-[1fr_18rem]">
          <div className="overflow-hidden rounded-xl bg-card ring-1 ring-foreground/10">
            <table className="w-full text-sm">
              <thead className="hidden border-b border-border text-left text-muted-foreground md:table-header-group">
                <tr>
                  <th className="px-4 py-3 font-medium">Product</th>
                  <th className="px-4 py-3 font-medium">Price</th>
                  <th className="px-4 py-3 font-medium">Qty</th>
                  <th className="px-4 py-3 font-medium">Subtotal</th>
                  <th className="px-4 py-3 font-medium">
                    <span className="sr-only">Remove</span>
                  </th>
                </tr>
              </thead>
              <tbody>
                {cart.items.map((item) => (<tr key={item.product.id} className="grid grid-cols-[4.5rem_1fr] gap-3 border-b border-border px-4 py-4 md:table-row">
                    <td className="md:px-4 md:py-4">
                      <Link to={`/products/${item.product.id}`} className="relative block size-16 overflow-hidden rounded-md bg-[#141210] md:size-14">
                        <ProductImage src={item.product.image} alt="" className="object-contain p-1" sizes="64px"/>
                      </Link>
                    </td>
                    <td className="md:px-4 md:py-4">
                      <Link to={`/products/${item.product.id}`} className="font-medium hover:underline">
                        {item.product.title}
                      </Link>
                      <p className="mt-1 text-muted-foreground md:hidden">{formatMoney(item.product.price)}</p>
                    </td>
                    <td className="hidden md:table-cell md:px-4 md:py-4">{formatMoney(item.product.price)}</td>
                    <td className="col-start-2 md:table-cell md:px-4 md:py-4">
                      <QuantityControl item={item} onInvalid={onInvalid}/>
                    </td>
                    <td className="hidden md:table-cell md:px-4 md:py-4">{formatMoney(item.lineTotal)}</td>
                    <td className="col-start-2 md:table-cell md:px-4 md:py-4">
                      <Button type="button" variant="outline" onClick={() => void remove(item)}>
                        Remove
                      </Button>
                    </td>
                  </tr>))}
              </tbody>
            </table>
          </div>
          <CartSummary cart={cart}>
            {checkoutDisabled ? (<Button type="button" className="mt-4 w-full" disabled>
                Checkout
              </Button>) : (<Link to="/checkout" className={cn(buttonVariants(), "mt-4 w-full")}>
                Checkout
              </Link>)}
            {blocked ? (<p className="mt-2 text-xs text-destructive">Fix the quantities before checking out.</p>) : null}
          </CartSummary>
        </div>)}
    </div>);
}
