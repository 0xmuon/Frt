import { formatMoney } from "@/lib/format";
export function PriceTag({ price, compareAt }) {
    return (<p className="flex items-baseline gap-2">
      <span className={compareAt != null ? "font-medium text-copper" : "font-medium"}>{formatMoney(price)}</span>
      {compareAt != null ? (<span className="text-sm text-muted-foreground line-through">{formatMoney(compareAt)}</span>) : null}
    </p>);
}
