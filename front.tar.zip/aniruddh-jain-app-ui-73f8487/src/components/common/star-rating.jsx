import { Star } from "lucide-react";
export function StarRating({ rating, count }) {
    const rounded = Math.round(rating);
    return (<p className="flex items-center gap-1 text-xs text-muted-foreground" aria-label={`Rated ${rating.toFixed(1)} out of 5`}>
      <span className="flex" aria-hidden="true">
        {Array.from({ length: 5 }, (_, index) => (<Star key={index} className={index < rounded ? "size-3.5 fill-copper text-copper" : "size-3.5 text-border"}/>))}
      </span>
      <span>
        {rating.toFixed(1)}
        {count != null ? ` (${count})` : ""}
      </span>
    </p>);
}
