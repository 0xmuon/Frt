export function PageHeader({ eyebrow, title, description, }) {
    return (<header className="mb-8 max-w-2xl">
      {eyebrow ? (<p className="text-xs font-medium tracking-[0.18em] text-copper uppercase">{eyebrow}</p>) : null}
      <h1 className="mt-1 text-4xl leading-tight">{title}</h1>
      {description ? <p className="mt-3 text-base text-muted-foreground">{description}</p> : null}
    </header>);
}
