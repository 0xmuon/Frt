import { useLocation, useNavigate } from "react-router-dom";
import { useEffect } from "react";
import { Skeleton } from "@/components/ui/skeleton";
import { useAuth } from "@/context/auth-context";
export function RequireAuth({ children }) {
    const { user, status } = useAuth();
    const navigate = useNavigate();
    const { pathname } = useLocation();
    useEffect(() => {
        if (status === "ready" && !user) {
            navigate(`/login?next=${encodeURIComponent(pathname)}`, { replace: true });
        }
    }, [status, user, pathname, navigate]);
    if (status !== "ready" || !user) {
        return (<div className="grid gap-4">
        <Skeleton className="h-10 w-56"/>
        <Skeleton className="h-40 w-full"/>
      </div>);
    }
    return children;
}
