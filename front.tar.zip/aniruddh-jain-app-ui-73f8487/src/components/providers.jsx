import { AuthProvider } from "@/context/auth-context";
import { CartProvider } from "@/context/cart-context";
import { WishlistProvider } from "@/context/wishlist-context";
import { Toaster } from "@/components/ui/sonner";
export function Providers({ children }) {
    return (<AuthProvider>
      <CartProvider>
        <WishlistProvider>
          {children}
          <Toaster position="top-center"/>
        </WishlistProvider>
      </CartProvider>
    </AuthProvider>);
}
