import { Link, useParams } from "react-router-dom";
import { useEffect, useState } from "react";
import { PageHeader } from "@/components/common/page-header";
import { ProductImage } from "@/components/products/product-image";
import { RequireAuth } from "@/components/common/require-auth";
import { Badge } from "@/components/ui/badge";
import { Button, buttonVariants } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { useAuth } from "@/context/auth-context";
import { formatDate, formatMoney } from "@/lib/format";
import { canReadAllOrders } from "@/lib/roles";
import { errorMessage } from "@/services/api-error";
import { shopApi } from "@/services/shop-api";
import { cn } from "@/lib/utils";
const statusLabel = {
    PENDING_PAYMENT: "Pending payment",
    CONFIRMED: "Confirmed",
    PAYMENT_FAILED: "Payment failed",
};
const paymentStatusLabel = {
    PENDING: "Pending",
    PAID: "Paid",
    FAILED: "Failed",
};
const paymentLabel = {
    CARD: "Credit Card",
    COD: "Cash on Delivery",
};
export function OrderHistory() {
    return (<RequireAuth>
      <OrderList />
    </RequireAuth>);
}
function OrderList() {
    const { user } = useAuth();
    const [orders, setOrders] = useState([]);
    const [status, setStatus] = useState("loading");
    const [message, setMessage] = useState(null);
    function load() {
        setStatus("loading");
        shopApi
            .listOrders()
            .then((next) => {
            setOrders(next);
            setStatus("ready");
        })
            .catch((error) => {
            setMessage(errorMessage(error, "Orders could not be loaded."));
            setStatus("error");
        });
    }
    useEffect(() => {
        let cancelled = false;
        shopApi
            .listOrders()
            .then((next) => {
            if (!cancelled) {
                setOrders(next);
                setStatus("ready");
            }
        })
            .catch((error) => {
            if (!cancelled) {
                setMessage(errorMessage(error, "Orders could not be loaded."));
                setStatus("error");
            }
        });
        return () => {
            cancelled = true;
        };
    }, []);
    return (<div>
      <PageHeader title="Order History" description={user && canReadAllOrders(user.role)
            ? "Every order in the shop. A customer still only sees their own."
            : "Orders placed with this account. Open one to see every line."}/>
      {status === "loading" ? (<div className="grid gap-4">
          <Skeleton className="h-40 w-full rounded-xl"/>
          <Skeleton className="h-40 w-full rounded-xl"/>
        </div>) : status === "error" ? (<div className="rounded-xl border border-destructive/30 p-6">
          <p className="text-sm">{message}</p>
          <Button type="button" className="mt-4" onClick={load}>
            Try again
          </Button>
        </div>) : orders.length === 0 ? (<p className="rounded-xl border border-dashed border-border px-6 py-16 text-center">No orders found.</p>) : (<div className="grid gap-6">
          {orders.map((order) => (<article key={order.id} className="rounded-xl bg-card p-5 ring-1 ring-foreground/10">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div>
                  <h2 className="text-xl">{order.orderNumber}</h2>
                  <p className="text-sm text-muted-foreground">{formatDate(order.createdAt)}</p>
                </div>
                <Badge variant="secondary">{statusLabel[order.status]}</Badge>
              </div>
              <table className="mt-4 w-full text-sm">
                <thead className="text-left text-muted-foreground">
                  <tr>
                    <th className="py-2 font-medium">Product</th>
                    <th className="py-2 font-medium">Qty</th>
                    <th className="py-2 font-medium">Price</th>
                    <th className="py-2 text-right font-medium">Subtotal</th>
                  </tr>
                </thead>
                <tbody>
                  {order.items.map((item) => (<tr key={`${order.id}-${item.productId}`} className="border-t border-border">
                      <td className="py-3">
                        <span className="flex items-center gap-3">
                          <span className="relative hidden size-10 overflow-hidden rounded bg-[#141210] sm:block">
                            <ProductImage src={item.image} alt="" className="object-contain p-1" sizes="40px"/>
                          </span>
                          {item.title}
                        </span>
                      </td>
                      <td className="py-3">{item.quantity}</td>
                      <td className="py-3">{formatMoney(item.unitPrice)}</td>
                      <td className="py-3 text-right">{formatMoney(item.lineTotal)}</td>
                    </tr>))}
                </tbody>
              </table>
              <div className="mt-4 flex flex-wrap items-center justify-between gap-3">
                <p className="font-medium">Total {formatMoney(order.total)}</p>
                <Link to={`/orders/${order.id}`} className={buttonVariants({ variant: "outline" })}>
                  View details
                </Link>
              </div>
            </article>))}
        </div>)}
    </div>);
}
export function OrderDetailRoute() {
    const params = useParams();
    return <OrderDetail id={params.id}/>;
}
export function OrderDetail({ id }) {
    return (<RequireAuth>
      <OrderDetailBody id={id}/>
    </RequireAuth>);
}
function OrderDetailBody({ id }) {
    const [order, setOrder] = useState(null);
    const [status, setStatus] = useState("loading");
    const [placed, setPlaced] = useState(false);
    const [retrying, setRetrying] = useState(false);
    const [retryError, setRetryError] = useState(null);
    const [notice, setNotice] = useState(null);
    const { user } = useAuth();
    useEffect(() => {
        const marker = window.sessionStorage.getItem("swiftshop.placed");
        if (marker === id) {
            // Clear the flag after the banner is scheduled. Removing it immediately
            // loses the message when React runs this effect twice in development.
            queueMicrotask(() => {
                setPlaced(true);
                if (window.sessionStorage.getItem("swiftshop.placed") === id) {
                    window.sessionStorage.removeItem("swiftshop.placed");
                }
            });
        }
        shopApi
            .getOrder(id)
            .then((next) => {
            setOrder(next);
            setStatus("ready");
        })
            .catch(() => {
            setStatus("missing");
        });
    }, [id]);
    if (status === "loading") {
        return <Skeleton className="h-72 w-full rounded-xl"/>;
    }
    if (status !== "ready" || !order) {
        return <PageHeader title="No orders found." description="That order is not on this account."/>;
    }
    return (<div className="grid gap-6">
      {placed ? (<p className="rounded-xl bg-foreground px-4 py-3 text-sm text-background" role="status">
          {order.paymentStatus === "PAID"
                ? `${order.orderNumber} is confirmed. A notice goes out after this page, so a slow email does not hold you here.`
                : `${order.orderNumber} is saved. The charge did not go through, and the stock is back.`}
        </p>) : null}
      <PageHeader eyebrow={statusLabel[order.status]} title={order.orderNumber} description={formatDate(order.createdAt)}/>
      <div className="grid gap-6 lg:grid-cols-[1fr_18rem]">
        <div className="rounded-xl bg-card p-5 ring-1 ring-foreground/10">
          <h2 className="text-xl">Products</h2>
          <ul className="mt-4 divide-y divide-border">
            {order.items.map((item) => (<li key={item.productId} className="flex gap-4 py-4">
                <Link to={`/products/${item.productId}`} className="relative size-16 shrink-0 overflow-hidden rounded-md bg-[#141210]">
                  <ProductImage src={item.image} alt="" className="object-contain p-1" sizes="64px"/>
                </Link>
                <div className="min-w-0 flex-1">
                  <p className="font-medium">{item.title}</p>
                  <p className="text-sm text-muted-foreground">
                    Qty {item.quantity} · {formatMoney(item.unitPrice)}
                  </p>
                </div>
                <p className="font-medium">{formatMoney(item.lineTotal)}</p>
              </li>))}
          </ul>
        </div>
        <aside className="grid h-fit gap-4 rounded-xl bg-card p-5 ring-1 ring-foreground/10">
          {order.shippingAddress.line1 ? (<div>
              <h2 className="text-xl">Delivery</h2>
              <p className="mt-2 text-sm leading-6">
                {order.shippingAddress.fullName}
                <br />
                {order.shippingAddress.line1}
                <br />
                {order.shippingAddress.city}, {order.shippingAddress.region} {order.shippingAddress.postalCode}
                <br />
                {order.shippingAddress.phone}
              </p>
            </div>) : null}
          <div>
            <h2 className="text-xl">Payment</h2>
            <p className="mt-2 text-sm">
              {paymentLabel[order.paymentMethod]}
              {order.cardLast4 ? ` ···· ${order.cardLast4}` : ""}
              {" · "}
              {paymentStatusLabel[order.paymentStatus]}
              {order.paymentReference ? ` · ${order.paymentReference}` : ""}
            </p>
            {order.failureReason ? <p className="mt-2 text-sm text-destructive">{order.failureReason}</p> : null}
            {order.status === "PAYMENT_FAILED" ? (<Button type="button" className="mt-3 w-full" disabled={retrying} onClick={() => {
                setRetrying(true);
                setRetryError(null);
                shopApi
                    .retryPayment(order.id)
                    .then((next) => setOrder(next))
                    .catch((error) => setRetryError(errorMessage(error, "The charge could not be tried again.")))
                    .finally(() => setRetrying(false));
            }}>
                {retrying ? "Trying the charge…" : "Try payment again"}
              </Button>) : null}
            {retryError ? <p className="mt-2 text-sm text-destructive">{retryError}</p> : null}
            {user && canReadAllOrders(user.role) ? (<Button type="button" variant="outline" className="mt-3 w-full" onClick={() => {
                setNotice(null);
                shopApi
                    .sendOrderNotice(order.id)
                    .then((message) => setNotice(message))
                    .catch((error) => setNotice(errorMessage(error, "The notice could not be queued.")));
            }}>
                Send notice
              </Button>) : null}
            {notice ? <p className="mt-2 text-sm">{notice}</p> : null}
          </div>
          <dl className="grid gap-1 text-sm">
            <div className="flex justify-between">
              <dt>Subtotal</dt>
              <dd>{formatMoney(order.subtotal)}</dd>
            </div>
            <div className="flex justify-between">
              <dt>Shipping</dt>
              <dd>{order.shipping === 0 ? "Free" : formatMoney(order.shipping)}</dd>
            </div>
            <div className="flex justify-between font-medium">
              <dt>Total</dt>
              <dd>{formatMoney(order.total)}</dd>
            </div>
          </dl>
          <Link to="/orders" className={cn(buttonVariants({ variant: "outline" }))}>
            Back to orders
          </Link>
        </aside>
      </div>
    </div>);
}
