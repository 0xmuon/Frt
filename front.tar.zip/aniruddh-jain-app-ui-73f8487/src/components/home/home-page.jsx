import { Link } from "react-router-dom";
import { useEffect, useState } from "react";
import { ProductImage } from "@/components/products/product-image";
import { ProductGrid, ProductGridSkeleton } from "@/components/products/product-grid";
import { buttonVariants } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { FREE_SHIPPING_AT } from "@/lib/pricing";
import { formatMoney } from "@/lib/format";
import { errorMessage } from "@/services/api-error";
import { shopApi } from "@/services/shop-api";
import { cn } from "@/lib/utils";
export function HomePage() {
    const [products, setProducts] = useState([]);
    const [categories, setCategories] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    useEffect(() => {
        let cancelled = false;
        Promise.all([shopApi.listProducts(), shopApi.listCategories()])
            .then(([nextProducts, nextCategories]) => {
            if (!cancelled) {
                setProducts(nextProducts);
                setCategories(nextCategories);
            }
        })
            .catch((cause) => {
            if (!cancelled) {
                setError(errorMessage(cause, "The shopping API on port 8000 did not answer."));
            }
        })
            .finally(() => {
            if (!cancelled) {
                setLoading(false);
            }
        });
        return () => {
            cancelled = true;
        };
    }, []);
    const featured = products.slice(0, 4);
    const deals = products.filter((product) => product.compareAtPrice != null).slice(0, 3);
    const arrivals = products.filter((product) => product.isNewArrival).slice(0, 3);
    return (<div className="grid gap-16">
      <section className="grid items-center gap-10 md:grid-cols-[1.1fr_0.9fr]">
        <div>
          <p className="text-xs font-medium tracking-[0.2em] text-copper uppercase">ABC&apos;s shop, online</p>
          <h1 className="mt-3 text-5xl leading-[1.05] md:text-6xl">The floor, now within reach.</h1>
          <p className="mt-4 max-w-md text-lg text-muted-foreground">
            SwiftShop is the counter ABC opened for the internet. Search the racks, keep a cart, and check out with a credit card or cash on delivery.
          </p>
          <div className="mt-6 flex flex-col gap-3 sm:flex-row">
            <Link to="/products" className={cn(buttonVariants({ size: "lg" }))}>
              Shop products
            </Link>
            <Link to="/deals" className={cn(buttonVariants({ size: "lg", variant: "outline" }))}>
              See deals
            </Link>
          </div>
          <ul className="mt-8 grid gap-3 text-sm text-muted-foreground sm:grid-cols-3">
            <li>Free shipping over {formatMoney(FREE_SHIPPING_AT)}</li>
            <li>24/7 customer support</li>
            <li>Easy 30-day returns</li>
          </ul>
        </div>
        <div className="grid grid-cols-2 gap-3">
          {loading
            ? Array.from({ length: 4 }, (_, index) => <Skeleton key={index} className="aspect-square rounded-xl"/>)
            : featured.map((product) => (<Link key={product.id} href={`/products/${product.id}`} className="relative aspect-square overflow-hidden rounded-xl bg-[#141210]">
                  <ProductImage src={product.image} alt={product.title} priority={product.id === featured[0]?.id} className="object-contain p-4" sizes="240px"/>
                </Link>))}
        </div>
      </section>

      {error ? (<p className="rounded-xl border border-destructive/30 bg-destructive/5 px-4 py-3 text-sm" role="alert">
          {error}
        </p>) : null}

      <section>
        <div className="mb-5 flex items-end justify-between gap-4">
          <h2 className="text-3xl">Categories</h2>
          <Link to="/categories" className="text-sm underline-offset-4 hover:underline">
            All categories
          </Link>
        </div>
        <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
          {categories.map((category) => (<Link key={category.slug} href={`/categories/${category.slug}`} className="group overflow-hidden rounded-xl bg-card ring-1 ring-foreground/10">
              <span className="relative block aspect-[4/3] bg-[#141210]">
                <ProductImage src={category.image} alt="" className="object-contain p-4 transition-transform group-hover:scale-105" sizes="240px"/>
              </span>
              <span className="block px-3 py-3">
                <span className="block text-sm font-medium">{category.name}</span>
                <span className="text-xs text-muted-foreground">{category.count} products</span>
              </span>
            </Link>))}
        </div>
      </section>

      <section>
        <div className="mb-5 flex items-end justify-between">
          <h2 className="text-3xl">Deals</h2>
          <Link to="/deals" className="text-sm underline-offset-4 hover:underline">
            Shop deals
          </Link>
        </div>
        {loading ? <ProductGridSkeleton /> : <ProductGrid products={deals}/>}
      </section>

      <section>
        <div className="mb-5 flex items-end justify-between">
          <h2 className="text-3xl">New arrivals</h2>
          <Link to="/new-arrivals" className="text-sm underline-offset-4 hover:underline">
            See what just landed
          </Link>
        </div>
        {loading ? null : <ProductGrid products={arrivals}/>}
      </section>
    </div>);
}
