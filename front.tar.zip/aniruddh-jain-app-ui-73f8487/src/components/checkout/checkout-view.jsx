import { useNavigate } from "react-router-dom";
import { useEffect, useState } from "react";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm, useWatch } from "react-hook-form";
import { CartSummary } from "@/components/cart/cart-view";
import { PageHeader } from "@/components/common/page-header";
import { RequireAuth } from "@/components/common/require-auth";
import { FormField } from "@/components/forms/form-field";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { useAuth } from "@/context/auth-context";
import { useCart } from "@/context/cart-context";
import { DEMO_CARD_NUMBER } from "@/lib/demo";
import { checkoutSchema } from "@/lib/validators";
import { errorMessage } from "@/services/api-error";
import { shopApi } from "@/services/shop-api";
const paymentItems = {
    CARD: "Credit Card",
    COD: "Cash on Delivery",
};
const emptyCheckout = {
    fullName: "",
    line1: "",
    city: "",
    region: "",
    postalCode: "",
    phone: "",
    paymentMethod: "COD",
    cardholder: "",
    cardNumber: "",
    expiry: "",
    cvv: "",
};
function formatCardNumber(value) {
    return value
        .replace(/\D/g, "")
        .slice(0, 16)
        .replace(/(\d{4})(?=\d)/g, "$1 ");
}
function formatExpiry(value) {
    const digits = value.replace(/\D/g, "").slice(0, 4);
    if (digits.length <= 2) {
        return digits;
    }
    return `${digits.slice(0, 2)}/${digits.slice(2)}`;
}
export function CheckoutView() {
    return (<RequireAuth>
      <CheckoutForm />
    </RequireAuth>);
}
function CheckoutForm() {
    const navigate = useNavigate();
    const { user } = useAuth();
    const { cart, status } = useCart();
    const [serverError, setServerError] = useState(null);
    const form = useForm({
        resolver: zodResolver(checkoutSchema),
        mode: "onChange",
        defaultValues: {
            ...emptyCheckout,
            fullName: user?.name ?? "",
            paymentMethod: "",
        },
    });
    useEffect(() => {
        if (user && form.getValues("fullName") === "") {
            form.setValue("fullName", user.name, { shouldValidate: true });
        }
    }, [user, form]);
    const { errors, dirtyFields, isValid, isSubmitting, submitCount } = form.formState;
    const paymentMethod = useWatch({ control: form.control, name: "paymentMethod" });
    const cardNumber = useWatch({ control: form.control, name: "cardNumber" });
    const expiry = useWatch({ control: form.control, name: "expiry" });
    function fieldError(name) {
        const message = errors[name]?.message;
        if (!message) {
            return undefined;
        }
        if (dirtyFields[name] || submitCount > 0) {
            return message;
        }
        return undefined;
    }
    async function onSubmit(values) {
        setServerError(null);
        try {
            const order = await shopApi.placeOrder({
                paymentMethod: values.paymentMethod,
                shippingAddress: {
                    fullName: values.fullName,
                    line1: values.line1,
                    city: values.city,
                    region: values.region,
                    postalCode: values.postalCode,
                    phone: values.phone,
                },
                card: values.paymentMethod === "CARD"
                    ? {
                        cardholder: values.cardholder,
                        number: values.cardNumber,
                        expiry: values.expiry,
                        cvv: values.cvv,
                    }
                    : undefined,
            });
            window.sessionStorage.setItem("swiftshop.placed", order.id);
            navigate(`/orders/${order.id}`);
        }
        catch (error) {
            setServerError(errorMessage(error, "The order could not be placed."));
        }
    }
    if (status !== "ready") {
        return <Skeleton className="h-80 w-full rounded-xl"/>;
    }
    if (cart.items.length === 0) {
        return (<PageHeader title="Nothing to check out" description="Your cart is empty. Add a product and the checkout form will be waiting."/>);
    }
    return (<div>
      <PageHeader title="Checkout" description="Review the order, then pay by credit card or cash on delivery. The charge runs after the order is reserved."/>
      <form noValidate onSubmit={form.handleSubmit(onSubmit)} className="grid items-start gap-8 lg:grid-cols-[1fr_18rem]">
        <div className="grid gap-5 rounded-xl bg-card p-5 ring-1 ring-foreground/10">
          <h2 className="text-xl">Shipping</h2>
          <FormField id="fullName" label="Full name" error={fieldError("fullName")}>
            <Input id="fullName" autoComplete="name" aria-invalid={fieldError("fullName") != null} {...form.register("fullName")}/>
          </FormField>
          <FormField id="line1" label="Street address" error={fieldError("line1")}>
            <Input id="line1" autoComplete="address-line1" aria-invalid={fieldError("line1") != null} {...form.register("line1")}/>
          </FormField>
          <div className="grid gap-5 sm:grid-cols-2">
            <FormField id="city" label="City" error={fieldError("city")}>
              <Input id="city" autoComplete="address-level2" aria-invalid={fieldError("city") != null} {...form.register("city")}/>
            </FormField>
            <FormField id="region" label="State or region" error={fieldError("region")}>
              <Input id="region" autoComplete="address-level1" aria-invalid={fieldError("region") != null} {...form.register("region")}/>
            </FormField>
          </div>
          <div className="grid gap-5 sm:grid-cols-2">
            <FormField id="postalCode" label="Postal code" error={fieldError("postalCode")}>
              <Input id="postalCode" autoComplete="postal-code" aria-invalid={fieldError("postalCode") != null} {...form.register("postalCode")}/>
            </FormField>
            <FormField id="phone" label="Phone" error={fieldError("phone")}>
              <Input id="phone" autoComplete="tel" aria-invalid={fieldError("phone") != null} {...form.register("phone")}/>
            </FormField>
          </div>

          <h2 className="pt-2 text-xl">Payment</h2>
          <FormField id="paymentMethod" label="Payment method" error={fieldError("paymentMethod")}>
            <Select items={paymentItems} value={paymentMethod === "CARD" || paymentMethod === "COD" ? paymentMethod : null} onValueChange={(value) => {
            if (value === "CARD" || value === "COD") {
                form.setValue("paymentMethod", value, { shouldValidate: true, shouldDirty: true });
            }
        }}>
              <SelectTrigger id="paymentMethod" aria-label="Payment method">
                <SelectValue placeholder="Choose a payment method"/>
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="CARD">Credit Card</SelectItem>
                <SelectItem value="COD">Cash on Delivery</SelectItem>
              </SelectContent>
            </Select>
          </FormField>

          {paymentMethod === "CARD" ? (<div className="grid gap-5">
              <p className="text-sm text-muted-foreground">
                Try {DEMO_CARD_NUMBER}, any future expiry, and any 3-digit code. The number is checked here and is not sent. The order is reserved first, then the payment service is charged.
              </p>
              <FormField id="cardholder" label="Name on card" error={fieldError("cardholder")}>
                <Input id="cardholder" autoComplete="cc-name" aria-invalid={fieldError("cardholder") != null} {...form.register("cardholder")}/>
              </FormField>
              <FormField id="cardNumber" label="Card number" error={fieldError("cardNumber")}>
                <Input id="cardNumber" inputMode="numeric" autoComplete="cc-number" aria-invalid={fieldError("cardNumber") != null} value={cardNumber} onChange={(event) => form.setValue("cardNumber", formatCardNumber(event.target.value), {
                shouldValidate: true,
                shouldDirty: true,
            })}/>
              </FormField>
              <div className="grid gap-5 sm:grid-cols-2">
                <FormField id="expiry" label="Expiry" error={fieldError("expiry")}>
                  <Input id="expiry" inputMode="numeric" autoComplete="cc-exp" placeholder="MM/YY" aria-invalid={fieldError("expiry") != null} value={expiry} onChange={(event) => form.setValue("expiry", formatExpiry(event.target.value), { shouldValidate: true, shouldDirty: true })}/>
                </FormField>
                <FormField id="cvv" label="Security code" error={fieldError("cvv")}>
                  <Input id="cvv" inputMode="numeric" autoComplete="cc-csc" aria-invalid={fieldError("cvv") != null} {...form.register("cvv")}/>
                </FormField>
              </div>
            </div>) : null}

          {serverError ? (<p className="rounded-lg bg-destructive/10 px-3 py-2 text-sm text-destructive" role="alert">
              {serverError}
            </p>) : null}

          <div className="flex flex-col gap-3 sm:flex-row">
            <Button type="submit" className="sm:flex-1" disabled={!isValid || isSubmitting || cart.items.length === 0}>
              {isSubmitting ? "Placing order…" : "Place order"}
            </Button>
            <Button type="button" variant="outline" disabled={isSubmitting} onClick={() => {
            setServerError(null);
            form.reset({
                ...emptyCheckout,
                fullName: user?.name ?? "",
                paymentMethod: "",
            });
        }}>
              Reset
            </Button>
          </div>
        </div>
        <CartSummary cart={cart}/>
      </form>
    </div>);
}
