import { Link } from "react-router-dom";
import { useEffect, useState } from "react";
import { PageHeader } from "@/components/common/page-header";
import { ProductGrid, ProductGridSkeleton } from "@/components/products/product-grid";
import { buttonVariants } from "@/components/ui/button";
import { useWishlist } from "@/context/wishlist-context";
import { shopApi } from "@/services/shop-api";
import { cn } from "@/lib/utils";
export function WishlistView() {
    const { ids, ready } = useWishlist();
    const [products, setProducts] = useState([]);
    const [loading, setLoading] = useState(true);
    useEffect(() => {
        let cancelled = false;
        shopApi
            .listProducts()
            .then((next) => {
            if (!cancelled) {
                setProducts(next);
            }
        })
            .finally(() => {
            if (!cancelled) {
                setLoading(false);
            }
        });
        return () => {
            cancelled = true;
        };
    }, []);
    const saved = products.filter((product) => ids.includes(product.id));
    return (<div>
      <PageHeader title="Wishlist" description="Pieces you saved for later. They stay in this browser until you remove them."/>
      {!ready || loading ? (<ProductGridSkeleton />) : saved.length === 0 ? (<div className="rounded-xl border border-dashed border-border px-6 py-16 text-center">
          <p>Nothing saved yet.</p>
          <Link to="/products" className={cn(buttonVariants(), "mt-4")}>
            Browse products
          </Link>
        </div>) : (<ProductGrid products={saved}/>)}
    </div>);
}
