import { useState } from "react";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm, useWatch } from "react-hook-form";
import { PageHeader } from "@/components/common/page-header";
import { FormField } from "@/components/forms/form-field";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { supportSchema } from "@/lib/validators";
const topics = {
    Order: "Order",
    Shipping: "Shipping",
    Returns: "Returns",
    "Something else": "Something else",
};
const emptySupport = {
    name: "",
    email: "",
    topic: "Order",
    message: "",
};
export function ContactForm() {
    const [sent, setSent] = useState(false);
    const form = useForm({
        resolver: zodResolver(supportSchema),
        mode: "onChange",
        defaultValues: { ...emptySupport, topic: "" },
    });
    const { errors, dirtyFields, isValid, isSubmitting, submitCount } = form.formState;
    const topic = useWatch({ control: form.control, name: "topic" });
    function show(name) {
        const message = errors[name]?.message;
        if (!message) {
            return undefined;
        }
        return dirtyFields[name] || submitCount > 0 ? message : undefined;
    }
    function onSubmit() {
        setSent(true);
        form.reset({ ...emptySupport, topic: "" });
    }
    return (<div className="mx-auto max-w-lg">
      <PageHeader title="Contact Us" description="Check a note for support@swiftshop.com. The shopping API does not keep a contact inbox, so send the message by email."/>
      {sent ? (<p className="mb-4 rounded-lg bg-muted px-3 py-2 text-sm" role="status">
          The note checks out. Send it to support@swiftshop.com.
        </p>) : null}
      <form noValidate onSubmit={form.handleSubmit(onSubmit)} className="grid gap-4">
        <FormField id="name" label="Full name" error={show("name")}>
          <Input id="name" autoComplete="name" aria-invalid={show("name") != null} {...form.register("name")}/>
        </FormField>
        <FormField id="email" label="Email address" error={show("email")}>
          <Input id="email" type="email" autoComplete="email" aria-invalid={show("email") != null} {...form.register("email")}/>
        </FormField>
        <FormField id="topic" label="Topic" error={show("topic")}>
          <Select items={topics} value={topic || null} onValueChange={(value) => {
            if (value && value in topics) {
                form.setValue("topic", value, { shouldValidate: true, shouldDirty: true });
            }
        }}>
            <SelectTrigger id="topic" aria-label="Topic">
              <SelectValue placeholder="Choose a topic"/>
            </SelectTrigger>
            <SelectContent>
              {Object.keys(topics).map((item) => (<SelectItem key={item} value={item}>
                  {item}
                </SelectItem>))}
            </SelectContent>
          </Select>
        </FormField>
        <FormField id="message" label="Message" error={show("message")}>
          <Textarea id="message" rows={5} aria-invalid={show("message") != null} {...form.register("message")}/>
        </FormField>
        <div className="flex flex-col gap-3 sm:flex-row">
          <Button type="submit" disabled={!isValid || isSubmitting}>
            {isSubmitting ? "Sending…" : "Send message"}
          </Button>
          <Button type="button" variant="outline" disabled={isSubmitting} onClick={() => {
            setSent(false);
            form.reset({ ...emptySupport, topic: "" });
        }}>
            Reset
          </Button>
        </div>
      </form>
    </div>);
}
