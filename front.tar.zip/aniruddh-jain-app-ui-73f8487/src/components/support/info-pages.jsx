import { Link } from "react-router-dom";
import { PageHeader } from "@/components/common/page-header";
import { FREE_SHIPPING_AT, SHIPPING_FEE } from "@/lib/pricing";
import { formatMoney } from "@/lib/format";
export function HelpPage() {
    return (<article className="mx-auto max-w-2xl">
      <PageHeader title="Help Center" description="Short answers for the things people ask at the counter."/>
      <div className="grid gap-6 text-sm leading-6">
        <section>
          <h2 className="text-2xl">Finding something</h2>
          <p className="mt-2 text-muted-foreground">
            Use the search in the header, or the search on the shop page. It matches product names and categories as you type. The category menu narrows the floor further.
          </p>
        </section>
        <section>
          <h2 className="text-2xl">Your cart</h2>
          <p className="mt-2 text-muted-foreground">
            Add to Cart is available only while a product is in stock. Quantities have to be whole numbers and cannot pass the stock we have left. The total updates when the quantity is valid.
          </p>
        </section>
        <section>
          <h2 className="text-2xl">Signing in</h2>
          <p className="mt-2 text-muted-foreground">
            You can browse and fill a cart as a guest. Checkout, order history, and the account page ask you to register or log in. A guest cart is kept and joined to the account when you sign in.
          </p>
        </section>
        <p>
          Still stuck? <Link to="/contact" className="underline-offset-4 hover:underline">Contact us</Link>.
        </p>
      </div>
    </article>);
}
export function ReturnsPage() {
    return (<article className="mx-auto max-w-2xl">
      <PageHeader title="Returns" description="Thirty days, in the condition we sent it."/>
      <div className="grid gap-4 text-sm leading-6 text-muted-foreground">
        <p>
          Unworn clothes, unworn shoes, and unused fragrance can come back within 30 days of delivery. Include the order number from your history so we can match the parcel.
        </p>
        <p>
          Start a return from the <Link to="/contact" className="text-foreground underline-offset-4 hover:underline">contact form</Link> and choose Returns. We email a label. Refunds go back to the original payment method.
        </p>
      </div>
    </article>);
}
export function ShippingPage() {
    return (<article className="mx-auto max-w-2xl">
      <PageHeader title="Shipping" description="One rate, and it disappears once the basket is full enough."/>
      <div className="grid gap-4 text-sm leading-6 text-muted-foreground">
        <p>
          Orders under {formatMoney(FREE_SHIPPING_AT)} ship for {formatMoney(SHIPPING_FEE)}. At {formatMoney(FREE_SHIPPING_AT)} and above, shipping is free. The cart summary shows which one you are on.
        </p>
        <p>Most parcels leave the next business day and arrive in 3 to 5 days. Cash on delivery is handed to the driver. Card payments are authorized when you place the order — this preview does not charge a real card.</p>
      </div>
    </article>);
}
