import { useNavigate } from "react-router-dom";
import { PageHeader } from "@/components/common/page-header";
import { RequireAuth } from "@/components/common/require-auth";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/context/auth-context";
import { formatDate } from "@/lib/format";
import { roleLabel } from "@/lib/roles";
export function AccountView() {
    return (<RequireAuth>
      <AccountPanel />
    </RequireAuth>);
}
function AccountPanel() {
    const navigate = useNavigate();
    const { user, logout } = useAuth();
    if (!user) {
        return null;
    }
    return (<div className="mx-auto max-w-lg">
      <PageHeader title="Account" description="The name, email, and role stored for your SwiftShop orders."/>
      <dl className="grid gap-4 text-sm">
        <div>
          <dt className="text-muted-foreground">Name</dt>
          <dd className="mt-1 text-base">{user.name}</dd>
        </div>
        <div>
          <dt className="text-muted-foreground">Email</dt>
          <dd className="mt-1 text-base">{user.email}</dd>
        </div>
        <div>
          <dt className="text-muted-foreground">Role</dt>
          <dd className="mt-1 text-base">
            {roleLabel(user.role)}
            {user.isActive ? "" : " · Inactive"}
          </dd>
        </div>
        {user.mobile ? (<div>
            <dt className="text-muted-foreground">Mobile</dt>
            <dd className="mt-1 text-base">{user.mobile}</dd>
          </div>) : null}
        <div>
          <dt className="text-muted-foreground">Member since</dt>
          <dd className="mt-1 text-base">{formatDate(user.createdAt)}</dd>
        </div>
      </dl>
      <Button type="button" variant="ghost" className="mt-8" onClick={() => {
            void logout().then(() => navigate("/"));
        }}>
        Log out
      </Button>
    </div>);
}
