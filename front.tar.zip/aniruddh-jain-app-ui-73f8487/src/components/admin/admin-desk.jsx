import { useEffect, useState } from "react";
import { PageHeader } from "@/components/common/page-header";
import { RequireAuth } from "@/components/common/require-auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { useAuth } from "@/context/auth-context";
import { formatDate } from "@/lib/format";
import { canChangeRoles, canReadAudit, roleLabel } from "@/lib/roles";
import { errorMessage } from "@/services/api-error";
import { shopApi } from "@/services/shop-api";
const roleItems = {
    CUSTOMER: "Customer",
    SUPPORT: "Support",
    ADMIN: "Admin",
};
export function AdminDesk() {
    return (<RequireAuth>
      <AdminBody />
    </RequireAuth>);
}
function AdminBody() {
    const { user } = useAuth();
    const [audit, setAudit] = useState([]);
    const [status, setStatus] = useState("loading");
    const [message, setMessage] = useState(null);
    const [note, setNote] = useState(null);
    const [roleUserId, setRoleUserId] = useState("");
    const [nextRole, setNextRole] = useState("CUSTOMER");
    const [rolePending, setRolePending] = useState(false);
    const [categoryName, setCategoryName] = useState("");
    const [createdCategoryId, setCreatedCategoryId] = useState("");
    const [productName, setProductName] = useState("");
    const [sku, setSku] = useState("");
    const [price, setPrice] = useState("10");
    const [quantity, setQuantity] = useState("5");
    const [catalogPending, setCatalogPending] = useState(false);
    function reloadAudit() {
        return shopApi.listAudit().then(setAudit);
    }
    useEffect(() => {
        if (!user || !canReadAudit(user.role)) {
            return;
        }
        let cancelled = false;
        shopApi
            .listAudit()
            .then((rows) => {
            if (!cancelled) {
                setAudit(rows);
                setStatus("ready");
            }
        })
            .catch((error) => {
            if (!cancelled) {
                setMessage(errorMessage(error, "The audit log could not be loaded."));
                setStatus("error");
            }
        });
        return () => {
            cancelled = true;
        };
    }, [user]);
    if (!user) {
        return null;
    }
    if (!canReadAudit(user.role)) {
        return (<PageHeader title="Audit log" description="Support can read every order. The audit log, catalog changes, and role changes stay with an admin."/>);
    }
    async function changeRole() {
        setRolePending(true);
        setMessage(null);
        setNote(null);
        try {
            await shopApi.updateRole(roleUserId.trim(), nextRole);
            await reloadAudit();
            setNote(`Role saved for ${roleUserId.trim()}.`);
        }
        catch (error) {
            setMessage(errorMessage(error, "The role could not be changed."));
        }
        finally {
            setRolePending(false);
        }
    }
    async function addCategory() {
        setCatalogPending(true);
        setMessage(null);
        setNote(null);
        try {
            const created = await shopApi.createCategory(categoryName);
            setCreatedCategoryId(created.id);
            setCategoryName("");
            await reloadAudit();
            setNote(`Category ${created.name} is id ${created.id}.`);
        }
        catch (error) {
            setMessage(errorMessage(error, "The category could not be created."));
        }
        finally {
            setCatalogPending(false);
        }
    }
    async function addProduct() {
        setCatalogPending(true);
        setMessage(null);
        setNote(null);
        try {
            const created = await shopApi.createProduct({
                name: productName,
                sku,
                price: Number(price),
                quantity: Number(quantity),
                categoryId: createdCategoryId,
                description: "Added from the admin desk.",
            });
            setProductName("");
            setSku("");
            await reloadAudit();
            setNote(`${created.title} is on the floor as ${created.sku ?? "a new SKU"}.`);
        }
        catch (error) {
            setMessage(errorMessage(error, "The product could not be created."));
        }
        finally {
            setCatalogPending(false);
        }
    }
    return (<div className="grid gap-10">
      <PageHeader title="Audit log" description="Catalog changes and payment results. Support cannot open this page."/>
      {message ? (<p className="text-sm text-destructive" role="alert">
          {message}
        </p>) : null}
      {note ? <p className="text-sm">{note}</p> : null}
      {status === "loading" ? (<Skeleton className="h-64 w-full rounded-xl"/>) : status === "error" ? (<Button type="button" onClick={() => window.location.reload()}>
          Try again
        </Button>) : (<>
          <div className="overflow-x-auto rounded-xl bg-card ring-1 ring-foreground/10">
            <table className="w-full text-sm">
              <thead className="border-b border-border text-left text-muted-foreground">
                <tr>
                  <th className="px-4 py-3 font-medium">When</th>
                  <th className="px-4 py-3 font-medium">Who</th>
                  <th className="px-4 py-3 font-medium">Action</th>
                  <th className="px-4 py-3 font-medium">Detail</th>
                </tr>
              </thead>
              <tbody>
                {audit.length === 0 ? (<tr>
                    <td className="px-4 py-8 text-muted-foreground" colSpan={4}>
                      No audit rows yet.
                    </td>
                  </tr>) : (audit.map((row) => (<tr key={row.id} className="border-t border-border">
                      <td className="px-4 py-3 whitespace-nowrap">{formatDate(row.createdAt)}</td>
                      <td className="px-4 py-3">{row.actorName}</td>
                      <td className="px-4 py-3">
                        {row.action} {row.resource}
                      </td>
                      <td className="px-4 py-3">{row.detail}</td>
                    </tr>)))}
              </tbody>
            </table>
          </div>

          {canChangeRoles(user.role) ? (<section className="grid gap-4">
              <h2 className="text-2xl">Roles</h2>
              <p className="text-sm text-muted-foreground">
                Your id is {user.id}. Changing your own role is refused. Paste another user id from their account.
              </p>
              <div className="flex flex-col gap-3 sm:flex-row">
                <Input aria-label="User id" placeholder="User id" value={roleUserId} onChange={(event) => setRoleUserId(event.target.value)}/>
                <Select items={roleItems} value={nextRole} onValueChange={(value) => {
                    if (value === "CUSTOMER" || value === "ADMIN" || value === "SUPPORT")
                        setNextRole(value);
                }}>
                  <SelectTrigger aria-label="New role" className="w-full sm:w-40">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="CUSTOMER">{roleLabel("CUSTOMER")}</SelectItem>
                    <SelectItem value="SUPPORT">{roleLabel("SUPPORT")}</SelectItem>
                    <SelectItem value="ADMIN">{roleLabel("ADMIN")}</SelectItem>
                  </SelectContent>
                </Select>
                <Button type="button" disabled={rolePending || roleUserId.trim() === ""} onClick={() => void changeRole()}>
                  {rolePending ? "Saving…" : "Save role"}
                </Button>
              </div>
            </section>) : null}

          <section className="grid gap-4">
            <h2 className="text-2xl">Catalog</h2>
            <p className="text-sm text-muted-foreground">
              A new category, then a product. Price must be above zero. The stored SKU is uppercase. Delete hides the product from the shop.
            </p>
            <div className="flex flex-col gap-3 sm:flex-row">
              <Input aria-label="Category name" placeholder="Category name" value={categoryName} onChange={(event) => setCategoryName(event.target.value)}/>
              <Button type="button" disabled={catalogPending || categoryName.trim() === ""} onClick={() => void addCategory()}>
                Add category
              </Button>
            </div>
            <div className="grid gap-3 sm:grid-cols-2">
              <Input aria-label="Product name" placeholder="Product name" value={productName} onChange={(event) => setProductName(event.target.value)}/>
              <Input aria-label="SKU" placeholder="SKU" value={sku} onChange={(event) => setSku(event.target.value)}/>
              <Input aria-label="Price" inputMode="decimal" value={price} onChange={(event) => setPrice(event.target.value)}/>
              <Input aria-label="Quantity" inputMode="numeric" value={quantity} onChange={(event) => setQuantity(event.target.value)}/>
              <Input aria-label="Category id" placeholder="Category id" value={createdCategoryId} onChange={(event) => setCreatedCategoryId(event.target.value)}/>
            </div>
            <Button type="button" disabled={catalogPending || productName.trim() === "" || sku.trim() === "" || createdCategoryId.trim() === ""} onClick={() => void addProduct()}>
              {catalogPending ? "Saving…" : "Add product"}
            </Button>
          </section>
        </>)}
    </div>);
}
