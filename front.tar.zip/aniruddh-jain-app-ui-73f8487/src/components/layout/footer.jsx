import { Link } from "react-router-dom";
import { Mail, Phone } from "lucide-react";
const shopLinks = [
    { href: "/", label: "Home" },
    { href: "/categories", label: "Categories" },
    { href: "/deals", label: "Deals" },
    { href: "/new-arrivals", label: "New Arrivals" },
];
const serviceLinks = [
    { href: "/help", label: "Help Center" },
    { href: "/returns", label: "Returns" },
    { href: "/shipping", label: "Shipping" },
    { href: "/contact", label: "Contact Us" },
];
export function Footer() {
    return (<footer className="mt-16 bg-[#161412] text-[#f4efe6]">
      <div className="mx-auto grid max-w-6xl gap-10 px-4 py-12 md:grid-cols-4 md:px-6">
        <div>
          <p className="font-serif text-xl">SwiftShop</p>
          <p className="mt-3 text-sm leading-6 text-[#d9d1c5]">
            Your one-stop shop for the latest products and unbeatable deals. Fast shipping and 24/7 customer support.
          </p>
        </div>
        <div>
          <p className="text-sm font-medium">Shop</p>
          <ul className="mt-3 grid gap-2 text-sm text-[#d9d1c5]">
            {shopLinks.map((link) => (<li key={link.href}>
                <Link to={link.href} className="hover:text-white">
                  {link.label}
                </Link>
              </li>))}
          </ul>
        </div>
        <div>
          <p className="text-sm font-medium">Customer Service</p>
          <ul className="mt-3 grid gap-2 text-sm text-[#d9d1c5]">
            {serviceLinks.map((link) => (<li key={link.href}>
                <Link to={link.href} className="hover:text-white">
                  {link.label}
                </Link>
              </li>))}
          </ul>
        </div>
        <div>
          <p className="text-sm font-medium">Connect</p>
          <ul className="mt-3 grid gap-2 text-sm text-[#d9d1c5]">
            <li>
              <a href="mailto:support@swiftshop.com" className="inline-flex items-center gap-2 hover:text-white">
                <Mail className="size-4" aria-hidden="true"/>
                support@swiftshop.com
              </a>
            </li>
            <li>
              <a href="tel:+1234567890" className="inline-flex items-center gap-2 hover:text-white">
                <Phone className="size-4" aria-hidden="true"/>
                +1 234 567 890
              </a>
            </li>
          </ul>
        </div>
      </div>
      <div className="border-t border-white/10">
        <div className="mx-auto flex max-w-6xl flex-col gap-2 px-4 py-4 text-xs text-[#b7aea2] sm:flex-row sm:items-center sm:justify-between md:px-6">
          <p>© 2026 SwiftShop. All rights reserved.</p>
          <p>Built with React</p>
        </div>
      </div>
    </footer>);
}
