import { Footer } from "@/components/layout/footer";
import { Header } from "@/components/layout/header";
import { MainContent } from "@/components/layout/main-content";
import { Menu } from "@/components/layout/menu";
export function AppShell({ children }) {
    return (<div className="flex min-h-full flex-1 flex-col">
      <Header />
      <div className="hidden border-b border-border py-1 md:block">
        <Menu />
      </div>
      <MainContent>{children}</MainContent>
      <Footer />
    </div>);
}
