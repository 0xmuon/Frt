import { Link, useLocation } from "react-router-dom";
import { cn } from "@/lib/utils";
export const menuLinks = [
    { href: "/", label: "Home" },
    { href: "/products", label: "Shop" },
    { href: "/categories", label: "Categories" },
    { href: "/deals", label: "Deals" },
    { href: "/new-arrivals", label: "New Arrivals" },
];
function isCurrent(pathname, href) {
    if (href === "/") {
        return pathname === "/";
    }
    return pathname === href || pathname.startsWith(`${href}/`);
}
/** Top navigation on desktop, and the same links inside the mobile side menu. */
export function Menu({ orientation = "horizontal", onNavigate, }) {
    const { pathname } = useLocation();
    const vertical = orientation === "vertical";
    return (<nav aria-label="Shop sections" className={vertical ? "" : "mx-auto max-w-6xl px-4 md:px-6"}>
      <ul className={vertical ? "grid gap-1" : "flex gap-1"}>
        {menuLinks.map((link) => {
            const current = isCurrent(pathname, link.href);
            return (<li key={link.href}>
              <Link to={link.href} aria-current={current ? "page" : undefined} onClick={onNavigate} className={cn("inline-flex rounded-md px-3 py-2 text-sm transition-colors", vertical && "w-full", current ? "bg-foreground text-background" : "text-muted-foreground hover:bg-muted hover:text-foreground")}>
                {link.label}
              </Link>
            </li>);
        })}
      </ul>
    </nav>);
}
