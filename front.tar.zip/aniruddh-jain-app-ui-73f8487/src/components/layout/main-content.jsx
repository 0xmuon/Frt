/** Central area. Each page renders its own content here. */
export function MainContent({ children }) {
    return (<main id="main-content" className="mx-auto w-full max-w-6xl flex-1 px-4 py-8 md:px-6 md:py-10">
      {children}
    </main>);
}
