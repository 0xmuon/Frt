import { Link, useParams } from "react-router-dom";
import { useEffect, useState } from "react";
import { PageHeader } from "@/components/common/page-header";
import { ProductImage } from "@/components/products/product-image";
import { ProductListing } from "@/components/products/product-listing";
import { Skeleton } from "@/components/ui/skeleton";
import { categoryName } from "@/lib/catalog";
import { errorMessage } from "@/services/api-error";
import { shopApi } from "@/services/shop-api";
export function CategoriesIndex() {
    const [categories, setCategories] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    useEffect(() => {
        let cancelled = false;
        shopApi
            .listCategories()
            .then((next) => {
            if (!cancelled) {
                setCategories(next);
            }
        })
            .catch((cause) => {
            if (!cancelled) {
                setError(errorMessage(cause, "The shopping API on port 8000 did not answer."));
            }
        })
            .finally(() => {
            if (!cancelled) {
                setLoading(false);
            }
        });
        return () => {
            cancelled = true;
        };
    }, []);
    return (<div>
      <PageHeader title="Categories" description="The departments on the floor. Open one to search inside it."/>
      {loading ? (<div className="grid grid-cols-2 gap-3 md:grid-cols-4">
          {Array.from({ length: 8 }, (_, index) => (<Skeleton key={index} className="h-48 rounded-xl"/>))}
        </div>) : error ? (<p className="rounded-xl border border-destructive/30 bg-destructive/5 px-4 py-3 text-sm" role="alert">
          {error}
        </p>) : (<div className="grid grid-cols-2 gap-3 md:grid-cols-4">
          {categories.map((category) => (<Link key={category.slug} href={`/categories/${category.slug}`} className="overflow-hidden rounded-xl bg-card ring-1 ring-foreground/10">
              <span className="relative block aspect-[4/3] bg-[#141210]">
                <ProductImage src={category.image} alt="" className="object-contain p-4" sizes="240px"/>
              </span>
              <span className="block px-3 py-3">
                <span className="block text-sm font-medium">{category.name}</span>
                <span className="text-xs text-muted-foreground">{category.count} products</span>
              </span>
            </Link>))}
        </div>)}
    </div>);
}
export function CategoryView() {
    const params = useParams();
    const slug = params.slug;
    return (<ProductListing title={categoryName(slug)} description={`Everything currently in ${categoryName(slug)}. Search still works inside this department.`} basePath={`/categories/${slug}`} lockedCategory={slug}/>);
}
