import { Link } from "react-router-dom";
import { useState } from "react";
import { Heart } from "lucide-react";
import { toast } from "sonner";
import { PriceTag } from "@/components/common/price-tag";
import { ProductImage } from "@/components/products/product-image";
import { StarRating } from "@/components/common/star-rating";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useCart } from "@/context/cart-context";
import { useWishlist } from "@/context/wishlist-context";
import { categoryName } from "@/lib/catalog";
import { errorMessage } from "@/services/api-error";
export function ProductCard({ product }) {
    const { addItem } = useCart();
    const { has, toggle } = useWishlist();
    const [pending, setPending] = useState(false);
    const saved = has(product.id);
    const inStock = product.stock > 0;
    const description = product.description.trim() || "Details are on the product page.";
    async function addToCart() {
        setPending(true);
        try {
            await addItem(product.id, 1);
            toast.success(`Added ${product.title} to your cart`);
        }
        catch (error) {
            toast.error(errorMessage(error, "Could not add that product."));
        }
        finally {
            setPending(false);
        }
    }
    return (<article className="flex h-full flex-col overflow-hidden rounded-xl bg-card ring-1 ring-foreground/10">
      <div className="relative">
        <Link to={`/products/${product.id}`} className="relative block aspect-square bg-[#141210]">
          <ProductImage src={product.image} alt={product.title} sizes="(min-width: 1024px) 30vw, (min-width: 640px) 45vw, 100vw" className="object-contain p-6"/>
        </Link>
        <button type="button" aria-pressed={saved} aria-label={saved ? `Remove ${product.title} from wishlist` : `Save ${product.title} to wishlist`} onClick={() => toggle(product.id)} className="absolute top-3 right-3 grid size-9 place-items-center rounded-full bg-background/90 text-foreground">
          <Heart className={saved ? "size-4 fill-copper text-copper" : "size-4"}/>
        </button>
        {product.compareAtPrice != null ? (<Badge className="absolute top-3 left-3 bg-copper text-white">Sale</Badge>) : null}
        {!inStock ? (<Badge variant="secondary" className="absolute bottom-3 left-3">
            Out of Stock
          </Badge>) : null}
      </div>
      <div className="flex flex-1 flex-col gap-2 p-4">
        <p className="text-xs tracking-wide text-muted-foreground uppercase">{categoryName(product.category)}</p>
        <h2 className="text-lg leading-snug">
          <Link to={`/products/${product.id}`} className="hover:underline">
            {product.title}
          </Link>
        </h2>
        <p className="line-clamp-2 text-sm text-muted-foreground">{description}</p>
        <StarRating rating={product.rating} count={product.reviewCount}/>
        <div className="mt-auto grid gap-3 pt-2">
          <PriceTag price={product.price} compareAt={product.compareAtPrice}/>
          {inStock && product.stock <= 3 ? (<p className="text-xs text-copper">Only {product.stock} left</p>) : null}
          <Button type="button" className="w-full" disabled={!inStock || pending} onClick={() => void addToCart()}>
            {pending ? "Adding…" : inStock ? "Add to Cart" : "Out of Stock"}
          </Button>
        </div>
      </div>
    </article>);
}
