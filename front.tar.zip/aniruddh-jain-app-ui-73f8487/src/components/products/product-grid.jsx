import { ProductCard } from "@/components/products/product-card";
import { Skeleton } from "@/components/ui/skeleton";
export function ProductGrid({ products }) {
    return (<div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
      {products.map((product) => (<ProductCard key={product.id} product={product}/>))}
    </div>);
}
export function ProductGridSkeleton() {
    return (<div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
      {Array.from({ length: 6 }, (_, index) => (<Skeleton key={index} className="h-[28rem] rounded-xl"/>))}
    </div>);
}
