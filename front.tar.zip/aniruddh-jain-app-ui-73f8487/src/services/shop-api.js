import * as guest from "@/services/guest-cart";
import * as remote from "@/services/remote-api";
/**
 * The UI talks only to this module. Every account, catalog, cart, and order
 * call goes to the shopping API (port 8000). A guest cart stays in the browser
 * until sign-in, because the cart route requires a token.
 */
export const shopApi = {
    register: remote.register,
    login: remote.login,
    currentUser: remote.currentUser,
    logout: remote.logout,
    listProducts: remote.listProducts,
    getProduct: remote.getProduct,
    listCategories: remote.listCategories,
    getCart: remote.getCart,
    getGuestCart: guest.getGuestCart,
    addToCart: remote.addToCart,
    addToGuestCart: guest.addToGuestCart,
    updateCartItem: remote.updateCartItem,
    updateGuestCartItem: guest.updateGuestCartItem,
    removeCartItem: remote.removeCartItem,
    removeGuestCartItem: guest.removeGuestCartItem,
    mergeCart: remote.mergeCart,
    readGuestCart: guest.readGuestCart,
    clearGuestCart: guest.clearGuestCart,
    placeOrder: remote.placeOrder,
    listOrders: remote.listOrders,
    getOrder: remote.getOrder,
    retryPayment: remote.retryPayment,
    listAudit: remote.listAudit,
    updateRole: remote.updateRole,
    deactivateProduct: remote.deactivateProduct,
    createCategory: remote.createCategory,
    createProduct: remote.createProduct,
    sendOrderNotice: remote.sendOrderNotice,
};
