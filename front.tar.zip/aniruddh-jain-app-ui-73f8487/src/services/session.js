const TOKEN_KEY = "swiftshop.token";
const REFRESH_KEY = "swiftshop.refresh";
export function readToken() {
    if (typeof window === "undefined") {
        return null;
    }
    return window.localStorage.getItem(TOKEN_KEY);
}
export function saveToken(token) {
    window.localStorage.setItem(TOKEN_KEY, token);
}
export function readRefresh() {
    if (typeof window === "undefined") {
        return null;
    }
    return window.localStorage.getItem(REFRESH_KEY);
}
export function saveRefresh(token) {
    window.localStorage.setItem(REFRESH_KEY, token);
}
export function clearToken() {
    window.localStorage.removeItem(TOKEN_KEY);
    window.localStorage.removeItem(REFRESH_KEY);
}
