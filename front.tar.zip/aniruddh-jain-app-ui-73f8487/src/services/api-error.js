/** Error raised by the shop service. `message` is safe to show in the UI. */
export class ApiError extends Error {
    status;
    constructor(message, status) {
        super(message);
        this.name = "ApiError";
        this.status = status;
    }
}
export function isApiError(error) {
    return error instanceof ApiError;
}
export function errorMessage(error, fallback) {
    return isApiError(error) ? error.message : fallback;
}
