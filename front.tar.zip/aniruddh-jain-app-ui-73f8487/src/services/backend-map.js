import { shippingFor } from "@/lib/pricing";
import { isRole } from "@/lib/roles";
/**
 * Turns Week 3 JSON (snake_case, and a few quoted-column aliases) into the
 * shapes the shop screens already use. Missing catalog extras stay empty.
 */
const EMPTY_ADDRESS = {
    fullName: "",
    line1: "",
    city: "",
    region: "",
    postalCode: "",
    phone: "",
};
export function isRecord(value) {
    return typeof value === "object" && value !== null && !Array.isArray(value);
}
function pick(record, keys) {
    for (const key of keys) {
        const value = record[key];
        if (value !== undefined && value !== null && value !== "") {
            return value;
        }
    }
    return undefined;
}
function asString(value, fallback = "") {
    if (typeof value === "string")
        return value;
    if (typeof value === "number" && Number.isFinite(value))
        return String(value);
    return fallback;
}
function asNumber(value, fallback = 0) {
    if (typeof value === "number" && Number.isFinite(value))
        return value;
    if (typeof value === "string" && value.trim() && Number.isFinite(Number(value)))
        return Number(value);
    return fallback;
}
function asBoolean(value, fallback) {
    if (typeof value === "boolean")
        return value;
    if (value === "true" || value === 1 || value === "1")
        return true;
    if (value === "false" || value === 0 || value === "0")
        return false;
    return fallback;
}
export function asList(body, keys) {
    if (Array.isArray(body))
        return body;
    if (!isRecord(body))
        return [];
    for (const key of keys) {
        if (Array.isArray(body[key]))
            return body[key];
    }
    return [];
}
export function numericId(id) {
    const parsed = Number(id);
    return Number.isInteger(parsed) ? parsed : id;
}
/** Week 4 labels stay Credit Card and Cash on Delivery. The API charges those as CARD and UPI. */
export function paymentMethodToApi(method) {
    return method === "COD" ? "UPI" : "CARD";
}
function paymentMethodFromApi(value) {
    return asString(value).toUpperCase() === "CARD" ? "CARD" : "COD";
}
function paymentStatusFromApi(value) {
    const text = asString(value).toUpperCase();
    if (text === "PAID" || text === "FAILED" || text === "PENDING")
        return text;
    return "PENDING";
}
function orderStatusFromApi(value, payment) {
    const text = asString(value).toUpperCase();
    if (text === "PENDING_PAYMENT" || text === "CONFIRMED" || text === "PAYMENT_FAILED")
        return text;
    if (payment === "PAID")
        return "CONFIRMED";
    if (payment === "FAILED")
        return "PAYMENT_FAILED";
    return "PENDING_PAYMENT";
}
function slugify(value) {
    const slug = value
        .trim()
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, "-")
        .replace(/^-|-$/g, "");
    return slug || "shop";
}
export function errorText(body) {
    if (!isRecord(body))
        return null;
    if (typeof body.message === "string" && body.message.trim())
        return body.message;
    if (typeof body.detail === "string" && body.detail.trim())
        return body.detail;
    if (Array.isArray(body.detail)) {
        const first = body.detail.find(isRecord);
        if (first && typeof first.msg === "string") {
            const loc = Array.isArray(first.loc)
                ? first.loc.filter((part) => part !== "body" && part !== "query").map(String).join(" ")
                : "";
            return loc ? `${loc}: ${first.msg}` : first.msg;
        }
    }
    return null;
}
export function mapUser(value) {
    if (!isRecord(value))
        return null;
    const id = pick(value, ["user_id", "id", "UserID"]);
    const email = pick(value, ["email", "Email"]);
    if (id === undefined || email === undefined)
        return null;
    const roleText = asString(pick(value, ["role", "Role"]), "CUSTOMER").toUpperCase();
    const role = isRole(roleText) ? roleText : "CUSTOMER";
    return {
        id: asString(id),
        name: asString(pick(value, ["name", "full_name", "user_name", "Name", "FullName"]), "Shopper"),
        email: asString(email),
        role,
        isActive: asBoolean(pick(value, ["is_active", "isActive", "IsActive"]), true),
        mobile: asString(pick(value, ["mobile", "Mobile"])) || undefined,
        createdAt: asString(pick(value, ["created_at", "createdAt", "CreatedAt"]), new Date(0).toISOString()),
    };
}
export function mapToken(value) {
    if (typeof value === "string" && value.trim())
        return { access: value, refresh: null };
    if (!isRecord(value))
        return null;
    const nested = isRecord(value.token) ? value.token : value;
    const access = pick(nested, ["access_token", "token", "accessToken"]);
    if (typeof access !== "string" || !access.trim())
        return null;
    const refresh = pick(nested, ["refresh_token", "refreshToken"]);
    return { access, refresh: typeof refresh === "string" && refresh.trim() ? refresh : null };
}
export function mapProduct(value, options) {
    if (!isRecord(value))
        return null;
    const id = pick(value, ["product_id", "id", "ProductID"]);
    if (id === undefined)
        return null;
    const title = asString(pick(value, ["product_name", "name", "title", "ProductName"]), `Product ${asString(id)}`);
    const category = asString(pick(value, ["category_name", "category", "CategoryName", "category_slug"]), "shop");
    const image = asString(pick(value, ["image", "image_url", "Image"]));
    const active = asBoolean(pick(value, ["is_active", "isActive", "IsActive"]), true);
    if (!active && !options?.keepInactive)
        return null;
    return {
        id: asNumber(id),
        title,
        description: asString(pick(value, ["description", "Description"]), "No description yet."),
        category: category.includes(" ") ? slugify(category) : slugify(category),
        price: asNumber(pick(value, ["price", "Price"])),
        compareAtPrice: null,
        rating: asNumber(pick(value, ["rating", "Rating"])),
        reviewCount: asNumber(pick(value, ["review_count", "reviewCount"])),
        stock: asNumber(pick(value, ["available_quantity", "stock", "AvailableQuantity"])),
        brand: asString(pick(value, ["brand", "Brand"])),
        image,
        isNewArrival: asBoolean(pick(value, ["is_new_arrival", "isNewArrival"]), false),
        sku: asString(pick(value, ["sku", "SKU"])) || undefined,
    };
}
export function mapCategory(value, products) {
    if (!isRecord(value))
        return null;
    const name = asString(pick(value, ["category_name", "name", "Name"]));
    if (!name)
        return null;
    const slug = slugify(asString(pick(value, ["slug", "category_slug"]), name));
    const counted = products.filter((product) => product.category === slug || product.category === slugify(name));
    return {
        slug,
        name,
        count: asNumber(pick(value, ["count", "product_count"]), counted.length),
        image: asString(pick(value, ["image", "image_url"]), counted[0]?.image ?? ""),
    };
}
function mapOrderLine(value) {
    if (!isRecord(value))
        return null;
    const product = isRecord(value.product) ? value.product : value;
    const quantity = asNumber(pick(value, ["quantity", "Quantity"]), 1);
    const unitPrice = asNumber(pick(value, ["unit_price", "price", "Price", "unitPrice"]));
    const title = asString(pick(product, ["product_name", "title", "name", "ProductName"]), "Product");
    const productId = asNumber(pick(value, ["product_id", "ProductID", "id"]));
    return {
        productId,
        title,
        image: asString(pick(product, ["image", "image_url"])),
        unitPrice,
        quantity,
        lineTotal: asNumber(pick(value, ["line_total", "lineTotal"]), Math.round(unitPrice * quantity * 100) / 100),
    };
}
function mapAddress(value, fallbackName) {
    if (!isRecord(value))
        return { ...EMPTY_ADDRESS, fullName: fallbackName };
    return {
        fullName: asString(pick(value, ["full_name", "fullName", "name"]), fallbackName),
        line1: asString(pick(value, ["line1", "address", "street"])),
        city: asString(pick(value, ["city"])),
        region: asString(pick(value, ["region", "state"])),
        postalCode: asString(pick(value, ["postal_code", "postalCode", "zip"])),
        phone: asString(pick(value, ["phone"])),
    };
}
export function mapOrder(value) {
    if (!isRecord(value))
        return null;
    const nested = isRecord(value.order) ? value.order : value;
    const id = pick(nested, ["order_id", "id", "OrderID"]);
    if (id === undefined)
        return null;
    const lines = asList(nested, ["details", "items", "order_details", "lines"])
        .map(mapOrderLine)
        .filter((line) => line !== null);
    const paymentStatus = paymentStatusFromApi(pick(nested, ["payment_status", "paymentStatus"]));
    const subtotal = lines.reduce((sum, line) => sum + line.lineTotal, 0);
    const total = asNumber(pick(nested, ["total", "total_amount", "TotalAmount"]), subtotal);
    const shipping = asNumber(pick(nested, ["shipping"]), total > 0 ? Math.max(0, Math.round((total - subtotal) * 100) / 100) : shippingFor(subtotal));
    const orderId = asString(id);
    const orderNumber = asString(pick(nested, ["order_number", "orderNumber", "number"]), `ORD-${orderId.padStart(6, "0")}`);
    return {
        id: orderId,
        orderNumber,
        userId: asString(pick(nested, ["user_id", "userId", "UserID"])),
        createdAt: asString(pick(nested, ["created_at", "createdAt", "CreatedAt"]), new Date().toISOString()),
        items: lines,
        itemCount: lines.reduce((sum, line) => sum + line.quantity, 0),
        subtotal: Math.round(subtotal * 100) / 100,
        shipping,
        total,
        paymentMethod: paymentMethodFromApi(pick(nested, ["payment_method", "paymentMethod", "method"])),
        cardLast4: asString(pick(nested, ["card_last4", "cardLast4"])) || null,
        shippingAddress: mapAddress(pick(nested, ["shipping_address", "shippingAddress", "address"]), ""),
        status: orderStatusFromApi(pick(nested, ["order_status", "status", "orderStatus"]), paymentStatus),
        paymentStatus,
        paymentReference: asString(pick(nested, ["payment_reference", "paymentReference", "reference"])) || null,
        failureReason: asString(pick(nested, ["failure_reason", "failureReason"])) || null,
    };
}
export function mapCart(value) {
    const lines = asList(value, ["items", "cart_items", "lines", "cart"]);
    if (lines.length === 0 && !Array.isArray(value) && !(isRecord(value) && ("items" in value || "cart_items" in value))) {
        return null;
    }
    const items = lines.flatMap((line) => {
        if (!isRecord(line))
            return [];
        const productSource = isRecord(line.product) ? { ...line.product, product_id: line.product.product_id ?? line.product_id } : line;
        const product = mapProduct(productSource, { keepInactive: true });
        if (!product)
            return [];
        const quantity = asNumber(pick(line, ["quantity", "Quantity"]), 1);
        const cartItemId = asString(pick(line, ["cart_item_id", "id", "CartItemID"]), `line-${product.id}`);
        return [
            {
                cartItemId,
                product: { ...product, stock: Math.max(product.stock, quantity) },
                quantity,
                lineTotal: Math.round(product.price * quantity * 100) / 100,
            },
        ];
    });
    const subtotal = Math.round(items.reduce((sum, item) => sum + item.lineTotal, 0) * 100) / 100;
    const shipping = items.length === 0 ? 0 : shippingFor(subtotal);
    return {
        items,
        itemCount: items.reduce((sum, item) => sum + item.quantity, 0),
        subtotal,
        shipping,
        total: Math.round((subtotal + shipping) * 100) / 100,
    };
}
export function mapAudit(value) {
    if (!isRecord(value))
        return null;
    const id = pick(value, ["audit_id", "id", "AuditID"]);
    if (id === undefined)
        return null;
    return {
        id: asString(id),
        actorId: asString(pick(value, ["actor_id", "actorId", "ActorID"])),
        actorName: asString(pick(value, ["actor_name", "actorName", "actor"]), "Staff"),
        action: asString(pick(value, ["action", "Action"]), "update"),
        resource: asString(pick(value, ["resource", "Resource"]), "record"),
        resourceId: asString(pick(value, ["resource_id", "resourceId", "ResourceID"])),
        detail: asString(pick(value, ["detail", "Detail"])),
        createdAt: asString(pick(value, ["created_at", "createdAt", "CreatedAt"]), new Date().toISOString()),
    };
}
