import { filterProducts, listCategories as groupCategories } from "@/lib/catalog";
import { canReadAllOrders } from "@/lib/roles";
import { ApiError } from "@/services/api-error";
import { asList, errorText, isRecord, mapAudit, mapCart, mapCategory, mapOrder, mapProduct, mapToken, mapUser, numericId, paymentMethodToApi, } from "@/services/backend-map";
import { clearToken, readRefresh, readToken, saveRefresh, saveToken } from "@/services/session";
/**
 * Client for the Week 3 shopping API on port 8000.
 * Paths match the demo cases. Checkout sends user_id and payment_method only.
 * Card numbers stay in the browser. Role is never sent on register.
 */
const EMPTY_CART = { items: [], itemCount: 0, subtotal: 0, shipping: 0, total: 0 };
/** Shopping API. Override with VITE_API_BASE_URL when it is not on this port. */
export function apiBaseUrl() {
    const configured = import.meta.env.VITE_API_BASE_URL?.trim();
    return (configured || "http://localhost:8000").replace(/\/$/, "");
}
function baseUrl() {
    return apiBaseUrl();
}
async function request(path, init) {
    const token = readToken();
    const headers = new Headers(init?.headers);
    const skipRefresh = init?.skipRefresh ?? false;
    headers.set("Accept", "application/json");
    if (init?.body) {
        headers.set("Content-Type", "application/json");
    }
    if (token) {
        headers.set("Authorization", `Bearer ${token}`);
    }
    let response;
    try {
        response = await fetch(`${baseUrl()}${path}`, {
            method: init?.method,
            body: init?.body,
            headers,
        });
    }
    catch {
        throw new ApiError(`The shopping API at ${baseUrl()} did not answer.`, 0);
    }
    if (response.status === 401 && !skipRefresh && readRefresh() && !path.startsWith("/api/auth/")) {
        const refreshed = await refreshAccess();
        if (refreshed) {
            return request(path, { ...init, skipRefresh: true });
        }
    }
    if (!response.ok) {
        let message = "Something went wrong. Please try again.";
        try {
            const body = await response.json();
            message = errorText(body) ?? message;
        }
        catch {
            // Keep the fallback when the body is not JSON.
        }
        if (response.status === 401) {
            clearToken();
        }
        throw new ApiError(message, response.status);
    }
    if (response.status === 204) {
        return null;
    }
    const text = await response.text();
    if (!text)
        return null;
    try {
        return JSON.parse(text);
    }
    catch {
        return text;
    }
}
async function refreshAccess() {
    const refresh = readRefresh();
    if (!refresh)
        return false;
    try {
        const response = await fetch(`${baseUrl()}/api/auth/refresh`, {
            method: "POST",
            headers: { Accept: "application/json", "Content-Type": "application/json" },
            body: JSON.stringify({ refresh_token: refresh }),
        });
        if (!response.ok) {
            clearToken();
            return false;
        }
        const body = await response.json();
        const tokens = mapToken(body);
        if (!tokens) {
            clearToken();
            return false;
        }
        saveToken(tokens.access);
        if (tokens.refresh)
            saveRefresh(tokens.refresh);
        return true;
    }
    catch {
        clearToken();
        return false;
    }
}
function remember(tokens) {
    saveToken(tokens.access);
    if (tokens.refresh)
        saveRefresh(tokens.refresh);
}
async function sessionFrom(body, fallback) {
    const tokens = mapToken(body);
    const embedded = mapUser(body) ?? (isRecord(body) ? mapUser(body.user) : null);
    if (tokens) {
        remember(tokens);
        const user = embedded ?? (await currentUser());
        return { token: tokens.access, user };
    }
    if (fallback) {
        return login(fallback);
    }
    throw new ApiError("The account was created, but no session token came back.", 502);
}
export async function register(input) {
    const body = await request("/api/users/register", {
        method: "POST",
        body: JSON.stringify({
            name: input.name,
            email: input.email,
            password: input.password,
            mobile: input.mobile,
        }),
    });
    return sessionFrom(body, input);
}
export async function login(input) {
    const body = await request("/api/auth/login", {
        method: "POST",
        body: JSON.stringify({ email: input.email, password: input.password }),
    });
    return sessionFrom(body);
}
export async function currentUser() {
    const body = await request("/api/auth/me");
    const user = mapUser(body) ?? (isRecord(body) ? mapUser(body.user) : null);
    if (!user) {
        throw new ApiError("Sign in to continue.", 401);
    }
    return user;
}
export async function logout() {
    try {
        await request("/api/auth/logout", { method: "POST", skipRefresh: true });
    }
    catch {
        // Logout still forgets the local tokens when the route is absent.
    }
    finally {
        clearToken();
    }
}
export async function listProducts(query = {}) {
    const path = query.q?.trim()
        ? `/api/products/search?name=${encodeURIComponent(query.q.trim())}`
        : "/api/products";
    const body = await request(path);
    const products = asList(body, ["products", "items"]).map((item) => mapProduct(item)).filter((item) => item !== null);
    return filterProducts(products, { ...query, q: undefined });
}
export async function getProduct(id) {
    const body = await request(`/api/products/${id}`);
    const product = mapProduct(body) ?? (isRecord(body) ? mapProduct(body.product) : null);
    if (!product) {
        throw new ApiError("We couldn't find that product.", 404);
    }
    return product;
}
export async function listCategories() {
    const products = await listProducts();
    try {
        const body = await request("/api/categories");
        const categories = asList(body, ["categories", "items"])
            .map((item) => mapCategory(item, products))
            .filter((item) => item !== null);
        if (categories.length > 0)
            return categories;
    }
    catch {
        // The shop can still group the products it already loaded.
    }
    return groupCategories(products);
}
async function signedCartUser() {
    return currentUser();
}
export async function getCart() {
    const user = await signedCartUser();
    const body = await request(`/api/cart/${encodeURIComponent(String(numericId(user.id)))}`);
    return mapCart(body) ?? EMPTY_CART;
}
export async function addToCart(productId, quantity) {
    const user = await signedCartUser();
    await request("/api/cart/add", {
        method: "POST",
        body: JSON.stringify({ user_id: numericId(user.id), product_id: productId, quantity }),
    });
    return getCart();
}
export async function updateCartItem(cartItemId, quantity) {
    await request(`/api/cart/update/${encodeURIComponent(cartItemId)}`, {
        method: "PUT",
        body: JSON.stringify({ quantity }),
    });
    return getCart();
}
export async function removeCartItem(cartItemId) {
    await request(`/api/cart/remove/${encodeURIComponent(cartItemId)}`, { method: "DELETE" });
    return getCart();
}
export async function mergeCart(items) {
    let cart = await getCart();
    for (const item of items) {
        cart = await addToCart(item.productId, item.quantity);
    }
    return cart;
}
export async function placeOrder(input) {
    const user = await currentUser();
    const body = await request("/api/orders/checkout", {
        method: "POST",
        body: JSON.stringify({
            user_id: numericId(user.id),
            payment_method: paymentMethodToApi(input.paymentMethod),
        }),
    });
    const order = mapOrder(body);
    if (!order)
        throw new ApiError("The order could not be read.", 502);
    return order;
}
export async function retryPayment(orderId) {
    const body = await request("/api/payments/process", {
        method: "POST",
        body: JSON.stringify({ order_id: numericId(orderId) }),
    });
    const order = mapOrder(body);
    if (order)
        return order;
    return getOrder(orderId);
}
export async function listOrders() {
    const user = await currentUser();
    const path = canReadAllOrders(user.role) ? "/api/admin/orders" : "/api/orders/me";
    const body = await request(path);
    return asList(body, ["orders", "items"]).map(mapOrder).filter((order) => order !== null);
}
export async function getOrder(id) {
    const body = await request(`/api/orders/details/${encodeURIComponent(id)}`);
    const order = mapOrder(body);
    if (!order)
        throw new ApiError("No orders found.", 404);
    return order;
}
export async function listAudit() {
    const body = await request("/api/admin/audit-logs");
    return asList(body, ["audit", "logs", "items", "entries"]).map(mapAudit).filter((row) => row !== null);
}
export async function updateRole(userId, role) {
    const body = await request(`/api/admin/users/${encodeURIComponent(userId)}/role`, {
        method: "PATCH",
        body: JSON.stringify({ role }),
    });
    const user = mapUser(body) ?? (isRecord(body) ? mapUser(body.user) : null);
    if (!user)
        throw new ApiError("The role could not be changed.", 502);
    return user;
}
export async function deactivateProduct(productId) {
    await request(`/api/admin/products/${productId}`, { method: "DELETE" });
}
export async function createCategory(categoryName) {
    const body = await request("/api/admin/categories", {
        method: "POST",
        body: JSON.stringify({ category_name: categoryName }),
    });
    if (!isRecord(body))
        throw new ApiError("The category could not be created.", 502);
    const id = body.category_id ?? body.id;
    return { id: String(id ?? ""), name: String(body.category_name ?? body.name ?? categoryName) };
}
export async function createProduct(input) {
    const body = await request("/api/admin/products", {
        method: "POST",
        body: JSON.stringify({
            product_name: input.name,
            sku: input.sku,
            price: input.price,
            available_quantity: input.quantity,
            category_id: numericId(input.categoryId),
            description: input.description,
        }),
    });
    const product = mapProduct(body) ?? (isRecord(body) ? mapProduct(body.product) : null);
    if (!product)
        throw new ApiError("The product could not be created.", 502);
    return product;
}
export async function sendOrderNotice(orderId) {
    const body = await request("/api/notifications/send", {
        method: "POST",
        body: JSON.stringify({ order_id: numericId(orderId) }),
    });
    if (isRecord(body) && typeof body.message === "string")
        return body.message;
    if (typeof body === "string" && body.trim())
        return body;
    return "Notification queued";
}
