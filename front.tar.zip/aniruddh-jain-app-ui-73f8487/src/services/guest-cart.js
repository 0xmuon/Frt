import { roundMoney, shippingFor } from "@/lib/pricing";
import { quantitySchema } from "@/lib/validators";
import { ApiError, isApiError } from "@/services/api-error";
import { getProduct } from "@/services/remote-api";
/**
 * Anonymous cart. GET /api/cart/{user_id} is 401 without a token, so a guest
 * basket stays in this browser and is merged with POST /api/cart/add at sign-in.
 */
const GUEST_CART_KEY = "swiftshop.guest-cart";
let queue = Promise.resolve();
function enqueue(task) {
    const run = queue.then(task, task);
    queue = run.then(() => undefined, () => undefined);
    return run;
}
function readGuestLines() {
    if (typeof window === "undefined") {
        return [];
    }
    const raw = window.localStorage.getItem(GUEST_CART_KEY);
    if (!raw) {
        return [];
    }
    try {
        const parsed = JSON.parse(raw);
        if (!Array.isArray(parsed)) {
            return [];
        }
        return parsed.flatMap((line) => {
            if (typeof line === "object" &&
                line !== null &&
                "productId" in line &&
                "quantity" in line &&
                typeof line.productId === "number" &&
                typeof line.quantity === "number") {
                const cartItemId = "cartItemId" in line && typeof line.cartItemId === "string" ? line.cartItemId : `guest-${line.productId}`;
                return [{ cartItemId, productId: line.productId, quantity: line.quantity }];
            }
            return [];
        });
    }
    catch {
        return [];
    }
}
function writeGuestLines(lines) {
    window.localStorage.setItem(GUEST_CART_KEY, JSON.stringify(lines));
}
function assertQuantity(quantity, stock) {
    const parsed = quantitySchema.safeParse(quantity);
    if (!parsed.success) {
        throw new ApiError(parsed.error.issues[0]?.message ?? "Quantity must be a positive integer.", 400);
    }
    if (stock <= 0) {
        throw new ApiError("Out of Stock", 400);
    }
    if (quantity > stock) {
        throw new ApiError(`Only ${stock} available.`, 400);
    }
}
async function productFor(productId) {
    try {
        return await getProduct(productId);
    }
    catch (error) {
        if (isApiError(error) && error.status === 404) {
            throw new ApiError("We couldn't find that product.", 404);
        }
        throw error;
    }
}
async function priceLines(lines) {
    const kept = [];
    const items = [];
    for (const line of lines) {
        let product;
        try {
            product = await productFor(line.productId);
        }
        catch (error) {
            if (isApiError(error) && error.status === 404) {
                continue;
            }
            throw error;
        }
        kept.push(line);
        items.push({
            cartItemId: line.cartItemId,
            product,
            quantity: line.quantity,
            lineTotal: roundMoney(product.price * line.quantity),
        });
    }
    if (kept.length !== lines.length) {
        writeGuestLines(kept);
    }
    const subtotal = roundMoney(items.reduce((sum, item) => sum + item.lineTotal, 0));
    const shipping = shippingFor(subtotal);
    const itemCount = items.reduce((sum, item) => sum + item.quantity, 0);
    return { items, itemCount, subtotal, shipping, total: roundMoney(subtotal + shipping) };
}
export function getGuestCart() {
    return enqueue(async () => priceLines(readGuestLines()));
}
export function addToGuestCart(productId, quantity) {
    return enqueue(async () => {
        const product = await productFor(productId);
        const lines = readGuestLines();
        const existing = lines.find((line) => line.productId === productId);
        const resolved = (existing?.quantity ?? 0) + quantity;
        assertQuantity(resolved, product.stock);
        const next = existing
            ? lines.map((line) => (line.productId === productId ? { ...line, quantity: resolved } : line))
            : [...lines, { cartItemId: `guest-${productId}`, productId, quantity: resolved }];
        writeGuestLines(next);
        return priceLines(next);
    });
}
export function updateGuestCartItem(cartItemId, quantity) {
    return enqueue(async () => {
        const lines = readGuestLines();
        const line = lines.find((item) => item.cartItemId === cartItemId);
        if (!line) {
            throw new ApiError("That cart line is gone.", 404);
        }
        const product = await productFor(line.productId);
        assertQuantity(quantity, product.stock);
        const next = lines.map((item) => (item.cartItemId === cartItemId ? { ...item, quantity } : item));
        writeGuestLines(next);
        return priceLines(next);
    });
}
export function removeGuestCartItem(cartItemId) {
    return enqueue(async () => {
        const next = readGuestLines().filter((line) => line.cartItemId !== cartItemId);
        writeGuestLines(next);
        return priceLines(next);
    });
}
export function readGuestCart() {
    return readGuestLines().map((line) => ({ productId: line.productId, quantity: line.quantity }));
}
export function clearGuestCart() {
    if (typeof window !== "undefined") {
        window.localStorage.removeItem(GUEST_CART_KEY);
    }
}
