import { useNavigate, useSearchParams } from "react-router-dom";
import { useEffect, useState } from "react";
import { PageHeader } from "@/components/common/page-header";
import { ProductGrid, ProductGridSkeleton } from "@/components/products/product-grid";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { SORT_OPTIONS } from "@/lib/catalog";
import { errorMessage } from "@/services/api-error";
import { shopApi } from "@/services/shop-api";
const sortItems = Object.fromEntries(SORT_OPTIONS.map((option) => [option.value, option.label]));
export function ProductListing({ title, description, basePath, lockedCategory }) {
    const navigate = useNavigate();
    const [params] = useSearchParams();
    const qParam = params.get("q") ?? "";
    const categoryParam = params.get("category") ?? "";
    const sortParam = params.get("sort") ?? "featured";
    const [query, setQuery] = useState(qParam);
    const [category, setCategory] = useState(lockedCategory ?? categoryParam);
    const [sort, setSort] = useState(SORT_OPTIONS.some((option) => option.value === sortParam) ? sortParam : "featured");
    const [products, setProducts] = useState([]);
    const [categories, setCategories] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [reloadKey, setReloadKey] = useState(0);
    useEffect(() => {
        queueMicrotask(() => setQuery(qParam));
    }, [qParam]);
    useEffect(() => {
        if (lockedCategory) {
            return;
        }
        queueMicrotask(() => setCategory(categoryParam));
    }, [categoryParam, lockedCategory]);
    useEffect(() => {
        const handle = window.setTimeout(() => {
            if (query === qParam) {
                return;
            }
            const next = new URLSearchParams(params.toString());
            if (query.trim()) {
                next.set("q", query.trim());
            }
            else {
                next.delete("q");
            }
            const text = next.toString();
            navigate(text ? `${basePath}?${text}` : basePath, { replace: true });
        }, 250);
        return () => window.clearTimeout(handle);
    }, [query, qParam, params, navigate, basePath]);
    useEffect(() => {
        let cancelled = false;
        shopApi
            .listProducts({
            q: query.trim(),
            category: lockedCategory || category || undefined,
            sort,
        })
            .then((next) => {
            if (!cancelled) {
                setProducts(next);
            }
        })
            .catch((cause) => {
            if (!cancelled) {
                setError(errorMessage(cause, "Products could not be loaded."));
            }
        })
            .finally(() => {
            if (!cancelled) {
                setLoading(false);
            }
        });
        shopApi
            .listCategories()
            .then((next) => {
            if (!cancelled) {
                setCategories(next);
            }
        })
            .catch(() => {
            // The product list already shows the API error. Categories can stay empty.
        });
        return () => {
            cancelled = true;
        };
    }, [query, category, sort, lockedCategory, reloadKey]);
    const categoryItems = {
        all: "All categories",
        ...Object.fromEntries(categories.map((item) => [item.slug, item.name])),
    };
    return (<div>
      <PageHeader title={title} description={description}/>
      <div className="mb-6 grid gap-3 md:grid-cols-[1fr_14rem_14rem]">
        <Input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search by name or category" aria-label="Search products"/>
        {lockedCategory ? null : (<Select items={categoryItems} value={category || "all"} onValueChange={(value) => {
            const nextCategory = !value || value === "all" ? "" : value;
            setCategory(nextCategory);
            const next = new URLSearchParams(params.toString());
            if (nextCategory) {
                next.set("category", nextCategory);
            }
            else {
                next.delete("category");
            }
            const text = next.toString();
            navigate(text ? `${basePath}?${text}` : basePath, { replace: true });
        }}>
            <SelectTrigger aria-label="Category">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {Object.entries(categoryItems).map(([value, label]) => (<SelectItem key={value} value={value}>
                  {label}
                </SelectItem>))}
            </SelectContent>
          </Select>)}
        <Select items={sortItems} value={sort} onValueChange={(value) => setSort(value || "featured")}>
          <SelectTrigger aria-label="Sort products">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {SORT_OPTIONS.map((option) => (<SelectItem key={option.value} value={option.value}>
                {option.label}
              </SelectItem>))}
          </SelectContent>
        </Select>
      </div>

      {error ? (<div className="rounded-xl border border-destructive/30 bg-destructive/5 p-6" role="alert">
          <p className="text-sm">{error}</p>
          <Button type="button" className="mt-4" onClick={() => setReloadKey((value) => value + 1)}>
            Try again
          </Button>
        </div>) : loading && products.length === 0 ? (<ProductGridSkeleton />) : products.length === 0 ? (<p className="rounded-xl border border-dashed border-border px-6 py-16 text-center text-muted-foreground">
          No products match that search.
        </p>) : (<div className="grid gap-4">
          <p className="text-sm text-muted-foreground">
            {products.length} {products.length === 1 ? "product" : "products"}
          </p>
          <ProductGrid products={products}/>
        </div>)}
    </div>);
}
