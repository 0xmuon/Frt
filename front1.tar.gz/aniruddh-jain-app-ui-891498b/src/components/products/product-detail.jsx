import { Link, useParams } from "react-router-dom";
import { useEffect, useState } from "react";
import { PageHeader } from "@/components/common/page-header";
import { PriceTag } from "@/components/common/price-tag";
import { ProductImage } from "@/components/products/product-image";
import { StarRating } from "@/components/common/star-rating";
import { ProductGrid } from "@/components/products/product-grid";
import { Skeleton } from "@/components/ui/skeleton";
import { categoryName, relatedProducts } from "@/lib/catalog";
import { errorMessage, isApiError } from "@/services/api-error";
import { shopApi } from "@/services/shop-api";
export function ProductDetail() {
    const params = useParams();
    return <ProductDetailBody key={params.id} id={Number(params.id)}/>;
}
function ProductDetailBody({ id }) {
    const [product, setProduct] = useState(null);
    const [related, setRelated] = useState([]);
    const [status, setStatus] = useState("loading");
    const [message, setMessage] = useState(null);
    useEffect(() => {
        if (!Number.isInteger(id)) {
            return;
        }
        let cancelled = false;
        Promise.all([shopApi.getProduct(id), shopApi.listProducts()])
            .then(([next, all]) => {
            if (cancelled) {
                return;
            }
            setProduct(next);
            setRelated(relatedProducts(all, next));
            setStatus("ready");
        })
            .catch((error) => {
            if (cancelled) {
                return;
            }
            if (isApiError(error) && (error.status === 404 || error.message.includes("couldn't find"))) {
                setStatus("missing");
                return;
            }
            setMessage(errorMessage(error, "This product could not be loaded."));
            setStatus("error");
        });
        return () => {
            cancelled = true;
        };
    }, [id]);
    if (!Number.isInteger(id) || status === "missing") {
        return (<PageHeader eyebrow="Missing" title="That product is not on the floor." description="It may have been retired. The rest of the shop is still open."/>);
    }
    if (status === "loading") {
        return (<div className="grid gap-8 md:grid-cols-2">
        <Skeleton className="aspect-square rounded-xl"/>
        <div className="grid content-start gap-3">
          <Skeleton className="h-8 w-2/3"/>
          <Skeleton className="h-4 w-1/3"/>
          <Skeleton className="h-24 w-full"/>
        </div>
      </div>);
    }
    if (status === "error" || !product) {
        return <p className="text-sm text-destructive" role="alert">{message}</p>;
    }
    const inStock = product.stock > 0;
    const description = product.description.trim() || "Details for this product are listed above.";
    return (<div className="grid gap-12">
      <div className="grid items-start gap-8 md:grid-cols-2">
        <div className="relative aspect-square overflow-hidden rounded-xl bg-[#141210]">
          <ProductImage src={product.image} alt={product.title} priority className="object-contain p-10" sizes="(min-width: 768px) 50vw, 100vw"/>
        </div>
        <div className="grid content-start gap-4">
          <p className="text-xs tracking-[0.16em] text-copper uppercase">
            <Link to={`/products?category=${encodeURIComponent(product.category)}`} className="hover:underline">
              {categoryName(product.category)}
            </Link>
            {product.brand ? ` · ${product.brand}` : ""}
          </p>
          <h1 className="text-4xl leading-tight">{product.title}</h1>
          {product.sku ? <p className="text-sm text-muted-foreground">SKU {product.sku}</p> : null}
          <StarRating rating={product.rating} count={product.reviewCount}/>
          <PriceTag price={product.price} compareAt={product.compareAtPrice}/>
          <p className="max-w-prose text-sm leading-6 text-muted-foreground">{description}</p>
          <p className="text-sm">{inStock ? `${product.stock} in stock` : "Out of Stock"}</p>
        </div>
      </div>
      {related.length > 0 ? (<section>
          <h2 className="mb-4 text-2xl">More in {categoryName(product.category)}</h2>
          <ProductGrid products={related}/>
        </section>) : null}
    </div>);
}
