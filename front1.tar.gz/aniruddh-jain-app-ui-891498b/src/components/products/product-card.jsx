import { Link } from "react-router-dom";
import { PriceTag } from "@/components/common/price-tag";
import { ProductImage } from "@/components/products/product-image";
import { StarRating } from "@/components/common/star-rating";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { categoryName } from "@/lib/catalog";
export function ProductCard({ product }) {
    const inStock = product.stock > 0;
    const description = product.description.trim() || "Details are on the product page.";
    return (<article className="flex h-full flex-col overflow-hidden rounded-xl bg-card ring-1 ring-foreground/10">
      <div className="relative">
        <Link to={`/products/${product.id}`} className="relative block aspect-square bg-[#141210]">
          <ProductImage src={product.image} alt={product.title} sizes="(min-width: 1024px) 30vw, (min-width: 640px) 45vw, 100vw" className="object-contain p-6"/>
        </Link>
        {product.compareAtPrice != null ? (<Badge className="absolute top-3 left-3 bg-copper text-white">Sale</Badge>) : null}
        {!inStock ? (<Badge variant="secondary" className="absolute bottom-3 left-3">
            Out of Stock
          </Badge>) : null}
      </div>
      <div className="flex flex-1 flex-col gap-2 p-4">
        <p className="text-xs tracking-wide text-muted-foreground uppercase">{categoryName(product.category)}</p>
        <h2 className="text-lg leading-snug">
          <Link to={`/products/${product.id}`} className="hover:underline">
            {product.title}
          </Link>
        </h2>
        <p className="line-clamp-2 text-sm text-muted-foreground">{description}</p>
        <StarRating rating={product.rating} count={product.reviewCount}/>
        <div className="mt-auto grid gap-3 pt-2">
          <PriceTag price={product.price} compareAt={product.compareAtPrice}/>
          {inStock && product.stock <= 3 ? (<p className="text-xs text-copper">Only {product.stock} left</p>) : null}
          <Button type="button" className="w-full" disabled={!inStock}>
            {inStock ? "Add to Cart" : "Out of Stock"}
          </Button>
        </div>
      </div>
    </article>);
}
