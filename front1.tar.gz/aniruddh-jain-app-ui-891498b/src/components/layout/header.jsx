import { Link, useNavigate } from "react-router-dom";
import { useEffect, useRef, useState } from "react";
import { Menu as MenuIcon, Search, ShoppingBag, UserRound } from "lucide-react";
import { Menu } from "@/components/layout/menu";
import { buttonVariants } from "@/components/ui/button";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger, } from "@/components/ui/dropdown-menu";
import { Input } from "@/components/ui/input";
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { useAuth } from "@/context/auth-context";
import { cn } from "@/lib/utils";
export function Header() {
    const navigate = useNavigate();
    const { user, status, logout } = useAuth();
    const [query, setQuery] = useState("");
    const [menuOpen, setMenuOpen] = useState(false);
    const searchEdited = useRef(false);
    function submitSearch(event) {
        event.preventDefault();
        const trimmed = query.trim();
        navigate(trimmed ? `/products?q=${encodeURIComponent(trimmed)}` : "/products");
    }
    useEffect(() => {
        if (!searchEdited.current) {
            return;
        }
        const trimmed = query.trim();
        const handle = window.setTimeout(() => {
            navigate(trimmed ? `/products?q=${encodeURIComponent(trimmed)}` : "/products", { replace: true });
        }, 250);
        return () => window.clearTimeout(handle);
    }, [query, navigate]);
    function onSearchChange(value) {
        searchEdited.current = true;
        setQuery(value);
    }
    return (<header className="sticky top-0 z-40 border-b border-border bg-background/90 backdrop-blur">
      <a href="#main-content" className="sr-only focus:not-sr-only focus:absolute focus:top-2 focus:left-2 focus:z-50 focus:rounded-md focus:bg-foreground focus:px-3 focus:py-2 focus:text-background">
        Skip to content
      </a>
      <div className="mx-auto flex max-w-6xl items-center gap-3 px-4 py-3 md:px-6">
        <Sheet open={menuOpen} onOpenChange={setMenuOpen}>
          <SheetTrigger className={cn(buttonVariants({ variant: "ghost", size: "icon" }), "md:hidden")} aria-label="Open menu">
            <MenuIcon />
          </SheetTrigger>
          <SheetContent side="left" className="w-72">
            <SheetHeader>
              <SheetTitle>SwiftShop</SheetTitle>
              <SheetDescription>Move around the shop.</SheetDescription>
            </SheetHeader>
            <div className="px-4">
              <Menu orientation="vertical" onNavigate={() => setMenuOpen(false)}/>
            </div>
          </SheetContent>
        </Sheet>

        <Link to="/" className="flex items-center gap-2 font-serif text-xl tracking-tight">
          <ShoppingBag className="size-5" aria-hidden="true"/>
          SwiftShop
        </Link>

        <form onSubmit={submitSearch} className="relative ml-auto hidden min-w-0 flex-1 md:ml-6 md:block md:max-w-md">
          <Search className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted-foreground"/>
          <Input value={query} onChange={(event) => onSearchChange(event.target.value)} placeholder="Search by name or category" aria-label="Search products" className="pl-9"/>
        </form>

        <div className="ml-auto flex items-center gap-1 md:ml-0">
          {status === "loading" ? (<span className="size-8 rounded-lg bg-muted" aria-hidden="true"/>) : (<DropdownMenu>
              <DropdownMenuTrigger className={buttonVariants({ variant: "ghost", size: "icon" })} aria-label={user ? `Account menu for ${user.name}` : "Account menu"}>
                <UserRound />
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-52">
                {user ? (<>
                    <DropdownMenuLabel>
                      <span className="block text-foreground">{user.name}</span>
                      <span className="block font-normal text-muted-foreground">{user.email}</span>
                    </DropdownMenuLabel>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem onClick={() => {
                    void logout().then(() => navigate("/"));
                }}>
                      Log out
                    </DropdownMenuItem>
                  </>) : (<>
                    <DropdownMenuItem onClick={() => navigate("/login")}>Login</DropdownMenuItem>
                    <DropdownMenuItem onClick={() => navigate("/register")}>Register</DropdownMenuItem>
                  </>)}
              </DropdownMenuContent>
            </DropdownMenu>)}
        </div>
      </div>

      <form onSubmit={submitSearch} className="px-4 pb-3 md:hidden">
        <div className="relative">
          <Search className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted-foreground"/>
          <Input value={query} onChange={(event) => onSearchChange(event.target.value)} placeholder="Search by name or category" aria-label="Search products" className="pl-9"/>
        </div>
      </form>
    </header>);
}
