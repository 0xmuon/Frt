import { ProductListing } from "@/components/products/product-listing";
import { useDocumentTitle } from "@/hooks/useDocumentTitle";

export function ProductsPage() {
  useDocumentTitle("Shop");
  return (
    <ProductListing
      title="Shop"
      description="Every product on the floor. Search by name or category. Add to Cart stays on only while stock remains."
      basePath="/products"
    />
  );
}
