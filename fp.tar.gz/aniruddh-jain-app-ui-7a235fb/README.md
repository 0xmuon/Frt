# SwiftShop

SwiftShop is the online counter for ABC's store. It is a Vite app written in React and JavaScript. This build covers the first two milestones: registration and login, then product listing and search.

The screens follow the reference layout: a header with the brand, navigation, and profile icon; a menu; a main area; and a footer with shop links and contact details.

## Run it

```bash
npm install
npm run dev
```

Open [http://127.0.0.1:43123](http://127.0.0.1:43123).

`index.html` and `src/main.jsx` start the app, `src/App.jsx` holds the routes, and screens live in `src/pages`. Shared UI is in `src/components`, the signed-in session is in `src/context`, the shopping API client is in `src/services`, and form rules are in `src/lib`.

The login page can fill three seeded accounts. A new registration is always a customer.

| Name | Email | Password | Role |
| --- | --- | --- | --- |
| Rudraksh | rudraksh@example.com | rudraksh1234 | Admin |
| Navya | navya@example.com | navya1234 | Support |
| Het | het@example.com | het12345 | Customer |

## What you can do

- Register with name, email, mobile, and password. The name is at least 6 letters and spaces. The password needs 8 characters, an uppercase letter, a lowercase letter, a number, and a special character. Mobile is 10 digits. The register button stays off until the form is valid, turns off while the request is in flight, and shows **Email must be unique** when that address is already taken. Reset clears the fields.
- Log in with an email and a password. The password is required. Bad credentials show **Invalid email or password.** An inactive account says **Account is inactive.** Reset clears the form.
- Search products by name or category as you type, and narrow them with the category dropdown and sort. An empty result says **No products match that search.**
- Product cards show the category, name, description, price, and stock. **Add to Cart** is enabled only while available quantity is above zero. Otherwise the card says **Out of Stock**.
- Open a product to read its details. The category link returns to that slice of the shop.

## Shopping API

This repo is the shop UI only. The shopping API is already running on port 8000. This project does not start it.

The UI calls `http://localhost:8000` unless you set another base with no trailing slash:

```bash
VITE_API_BASE_URL=http://localhost:8000
```

The browser calls that host directly, so the API has to allow this site’s origin (`http://127.0.0.1:43123` when you use the dev server). If port 8000 is down, the page says the shopping API did not answer.

| What | Request |
| --- | --- |
| Register | `POST /api/users/register` with `name`, `email`, `password`, `mobile`. No role. |
| Login, refresh, me | `POST /api/auth/login`, `POST /api/auth/refresh`, `GET /api/auth/me` |
| Browse | `GET /api/products`, `GET /api/products/:id`, `GET /api/categories` |

Search runs in the browser against that catalog, so a name or a category matches as you type. The category dropdown narrows the same list.

Logout clears the tokens kept in this browser. A missing logout route is ignored.
