import { Link, useNavigate } from "react-router-dom";
import { useEffect, useRef, useState } from "react";
import { Menu } from "@/components/layout/menu";
import { buttonVariants } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { useAuth } from "@/context/auth-context";
import { cn } from "@/lib/utils";

export function Header() {
  const navigate = useNavigate();
  const { user, status, logout } = useAuth();
  const [query, setQuery] = useState("");
  const [menuOpen, setMenuOpen] = useState(false);
  const searchEdited = useRef(false);

  function submitSearch(event) {
    event.preventDefault();
    const trimmed = query.trim();
    navigate(trimmed ? `/products?q=${encodeURIComponent(trimmed)}` : "/products");
  }

  useEffect(() => {
    if (!searchEdited.current) {
      return;
    }
    const trimmed = query.trim();
    const handle = window.setTimeout(() => {
      navigate(trimmed ? `/products?q=${encodeURIComponent(trimmed)}` : "/products", { replace: true });
    }, 250);
    return () => window.clearTimeout(handle);
  }, [query, navigate]);

  function onSearchChange(value) {
    searchEdited.current = true;
    setQuery(value);
  }

  return (
    <header className="border-b border-border">
      <a href="#main-content" className="sr-only focus:not-sr-only focus:absolute focus:top-2 focus:left-2 focus:z-50 focus:bg-foreground focus:px-3 focus:py-2 focus:text-background">
        Skip to content
      </a>
      <div className="mx-auto flex max-w-6xl items-center gap-4 px-4 py-3 md:px-6">
        <Sheet open={menuOpen} onOpenChange={setMenuOpen}>
          <SheetTrigger className={cn(buttonVariants({ variant: "outline", size: "sm" }), "md:hidden")} aria-label="Open menu">
            Menu
          </SheetTrigger>
          <SheetContent side="left" className="w-64">
            <SheetHeader>
              <SheetTitle>Menu</SheetTitle>
            </SheetHeader>
            <div className="px-4">
              <Menu orientation="vertical" onNavigate={() => setMenuOpen(false)} />
            </div>
          </SheetContent>
        </Sheet>

        <Link to="/" className="text-lg font-bold">
          SwiftShop
        </Link>

        <form onSubmit={submitSearch} className="ml-auto hidden min-w-0 flex-1 md:block md:max-w-sm">
          <Input
            value={query}
            onChange={(event) => onSearchChange(event.target.value)}
            placeholder="Search by name or category"
            aria-label="Search products"
          />
        </form>

        <div className="ml-auto flex items-center gap-3 text-sm md:ml-0">
          {status === "loading" ? null : user ? (
            <>
              <span>{user.name}</span>
              <button
                type="button"
                className="underline"
                onClick={() => {
                  void logout().then(() => navigate("/"));
                }}
              >
                Log out
              </button>
            </>
          ) : (
            <>
              <Link to="/login" className="underline">
                Login
              </Link>
              <Link to="/register" className="underline">
                Register
              </Link>
            </>
          )}
        </div>
      </div>

      <form onSubmit={submitSearch} className="px-4 pb-3 md:hidden">
        <Input
          value={query}
          onChange={(event) => onSearchChange(event.target.value)}
          placeholder="Search by name or category"
          aria-label="Search products"
        />
      </form>
    </header>
  );
}
