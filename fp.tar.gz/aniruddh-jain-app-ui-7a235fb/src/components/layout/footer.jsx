import { Link } from "react-router-dom";

export function Footer() {
  return (
    <footer className="mt-10 border-t border-border">
      <p className="mx-auto max-w-6xl px-4 py-4 text-sm md:px-6">
        <Link to="/" className="underline">
          Home
        </Link>
        {" · "}
        <Link to="/products" className="underline">
          Shop
        </Link>
        {" · "}
        <Link to="/login" className="underline">
          Login
        </Link>
        {" · "}
        <Link to="/register" className="underline">
          Register
        </Link>
      </p>
    </footer>
  );
}
