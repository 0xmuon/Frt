import { Link } from "react-router-dom";
import { useEffect, useState } from "react";
import { categoryName } from "@/lib/catalog";
import { errorMessage } from "@/services/api-error";
import { shopApi } from "@/services/shop-api";

export function HomePage() {
  const [categories, setCategories] = useState([]);
  const [error, setError] = useState(null);

  useEffect(() => {
    let cancelled = false;
    shopApi
      .listCategories()
      .then((nextCategories) => {
        if (!cancelled) {
          setCategories(nextCategories);
        }
      })
      .catch((cause) => {
        if (!cancelled) {
          setError(errorMessage(cause, "The shopping API on port 8000 did not answer."));
        }
      });
    return () => {
      cancelled = true;
    };
  }, []);

  return (
    <div>
      <h1 className="text-2xl">SwiftShop</h1>
      <p className="mt-2">Search products by name or category.</p>
      <p className="mt-4">
        <Link to="/products" className="underline">
          Shop
        </Link>
        {" · "}
        <Link to="/register" className="underline">
          Register
        </Link>
        {" · "}
        <Link to="/login" className="underline">
          Login
        </Link>
      </p>

      {error ? (
        <p className="mt-4 text-destructive" role="alert">
          {error}
        </p>
      ) : null}

      {categories.length > 0 ? (
        <div className="mt-8">
          <h2 className="text-lg">Categories</h2>
          <ul className="mt-2 list-disc pl-5">
            {categories.map((category) => (
              <li key={category.slug}>
                <Link to={`/products?category=${encodeURIComponent(category.slug)}`} className="underline">
                  {category.name || categoryName(category.slug)}
                </Link>
                {` (${category.count})`}
              </li>
            ))}
          </ul>
        </div>
      ) : null}
    </div>
  );
}
