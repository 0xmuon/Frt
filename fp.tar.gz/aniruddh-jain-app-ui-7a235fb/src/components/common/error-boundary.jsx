import { Component } from "react";

import { Button } from "@/components/ui/button";

export class ErrorBoundary extends Component {
  constructor(props) {
    super(props);
    this.state = { error: null };
  }

  static getDerivedStateFromError(error) {
    return { error };
  }

  render() {
    if (!this.state.error) {
      return this.props.children;
    }
    return (
      <div className="mx-auto max-w-lg py-16 text-center">
        <h1 className="text-2xl">This page could not be loaded.</h1>
        <Button type="button" className="mt-6" onClick={() => this.setState({ error: null })}>
          Try again
        </Button>
      </div>
    );
  }
}
