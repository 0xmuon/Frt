export function PageHeader({ title, description }) {
  return (
    <header className="mb-6">
      <h1 className="text-2xl">{title}</h1>
      {description ? <p className="mt-2">{description}</p> : null}
    </header>
  );
}
