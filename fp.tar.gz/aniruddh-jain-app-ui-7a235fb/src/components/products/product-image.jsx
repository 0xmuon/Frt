import { cn } from "@/lib/utils";

/** Catalog photo. A missing or remote URL still leaves a readable frame. */
export function ProductImage({ src, alt, className }) {
  if (!src) {
    return (
      <span className="absolute inset-0 grid place-items-center px-3 text-center text-sm">
        {alt || "Product"}
      </span>
    );
  }
  return <img src={src} alt={alt} className={cn("absolute inset-0 h-full w-full", className)} />;
}
