import { Link, useParams } from "react-router-dom";
import { useEffect, useState } from "react";
import { PriceTag } from "@/components/common/price-tag";
import { ProductImage } from "@/components/products/product-image";
import { Skeleton } from "@/components/ui/skeleton";
import { categoryName } from "@/lib/catalog";
import { errorMessage, isApiError } from "@/services/api-error";
import { shopApi } from "@/services/shop-api";

export function ProductDetail() {
  const params = useParams();
  return <ProductDetailBody key={params.id} id={Number(params.id)} />;
}

function ProductDetailBody({ id }) {
  const [product, setProduct] = useState(null);
  const [status, setStatus] = useState("loading");
  const [message, setMessage] = useState(null);

  useEffect(() => {
    if (!Number.isInteger(id)) {
      return;
    }
    let cancelled = false;
    shopApi
      .getProduct(id)
      .then((next) => {
        if (!cancelled) {
          setProduct(next);
          setStatus("ready");
        }
      })
      .catch((error) => {
        if (cancelled) {
          return;
        }
        if (isApiError(error) && (error.status === 404 || error.message.includes("couldn't find"))) {
          setStatus("missing");
          return;
        }
        setMessage(errorMessage(error, "This product could not be loaded."));
        setStatus("error");
      });
    return () => {
      cancelled = true;
    };
  }, [id]);

  if (!Number.isInteger(id) || status === "missing") {
    return (
      <div>
        <h1 className="text-2xl">Product not found</h1>
        <p className="mt-2">
          <Link to="/products" className="underline">
            Back to shop
          </Link>
        </p>
      </div>
    );
  }
  if (status === "loading") {
    return (
      <div className="grid gap-4 md:grid-cols-2">
        <Skeleton className="aspect-square" />
        <div className="grid content-start gap-3">
          <Skeleton className="h-6 w-2/3" />
          <Skeleton className="h-4 w-1/3" />
          <Skeleton className="h-16 w-full" />
        </div>
      </div>
    );
  }
  if (status === "error" || !product) {
    return (
      <p className="text-destructive" role="alert">
        {message}
      </p>
    );
  }
  const inStock = product.stock > 0;
  const description = product.description.trim() || "No description.";
  return (
    <div className="grid items-start gap-6 md:grid-cols-2">
      <div className="relative aspect-square bg-[#f3f3f3]">
        <ProductImage src={product.image} alt={product.title} className="object-contain" />
      </div>
      <div>
        <p>
          <Link to={`/products?category=${encodeURIComponent(product.category)}`} className="underline">
            {categoryName(product.category)}
          </Link>
        </p>
        <h1 className="mt-1 text-2xl">{product.title}</h1>
        <div className="mt-3">
          <PriceTag price={product.price} />
        </div>
        <p className="mt-3">{description}</p>
        <p className="mt-3">{inStock ? `${product.stock} in stock` : "Out of Stock"}</p>
      </div>
    </div>
  );
}
