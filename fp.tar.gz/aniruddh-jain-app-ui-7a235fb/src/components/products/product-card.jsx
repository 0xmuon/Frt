import { Link } from "react-router-dom";
import { PriceTag } from "@/components/common/price-tag";
import { ProductImage } from "@/components/products/product-image";
import { Button } from "@/components/ui/button";
import { categoryName } from "@/lib/catalog";

export function ProductCard({ product }) {
  const inStock = product.stock > 0;
  const description = product.description.trim() || "No description.";
  return (
    <article className="flex h-full flex-col border border-border p-3">
      <Link to={`/products/${product.id}`} className="relative block aspect-square bg-[#f3f3f3]">
        <ProductImage src={product.image} alt={product.title} className="object-contain" />
      </Link>
      <div className="mt-3 flex flex-1 flex-col gap-1">
        <p>{categoryName(product.category)}</p>
        <h2>
          <Link to={`/products/${product.id}`} className="underline">
            {product.title}
          </Link>
        </h2>
        <p>{description}</p>
        <div className="mt-auto grid gap-2 pt-2">
          <PriceTag price={product.price} />
          <p>{inStock ? `${product.stock} in stock` : "Out of Stock"}</p>
          <Button type="button" disabled={!inStock}>
            {inStock ? "Add to Cart" : "Out of Stock"}
          </Button>
        </div>
      </div>
    </article>
  );
}
