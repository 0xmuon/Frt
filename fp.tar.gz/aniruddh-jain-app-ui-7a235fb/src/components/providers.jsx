import { AuthProvider } from "@/context/auth-context";
import { Toaster } from "@/components/ui/sonner";

export function Providers({ children }) {
  return (
    <AuthProvider>
      {children}
      <Toaster position="top-center" />
    </AuthProvider>
  );
}
