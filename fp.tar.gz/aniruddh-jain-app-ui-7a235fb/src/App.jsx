import { BrowserRouter, Route, Routes, useLocation } from "react-router-dom";

import { ErrorBoundary } from "@/components/common/error-boundary";
import { AppShell } from "@/components/layout/app-shell";
import { Providers } from "@/components/providers";
import { HomePage } from "@/pages/HomePage";
import { LoginPage } from "@/pages/LoginPage";
import { NotFoundPage } from "@/pages/NotFoundPage";
import { ProductPage } from "@/pages/ProductPage";
import { ProductsPage } from "@/pages/ProductsPage";
import { RegisterPage } from "@/pages/RegisterPage";

function ShopRoutes() {
  const location = useLocation();
  return (
    <ErrorBoundary key={location.pathname}>
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/products" element={<ProductsPage />} />
        <Route path="/products/:id" element={<ProductPage />} />
        <Route path="/login" element={<LoginPage />} />
        <Route path="/register" element={<RegisterPage />} />
        <Route path="*" element={<NotFoundPage />} />
      </Routes>
    </ErrorBoundary>
  );
}

export default function App() {
  return (
    <Providers>
      <BrowserRouter>
        <AppShell>
          <ShopRoutes />
        </AppShell>
      </BrowserRouter>
    </Providers>
  );
}
