import { Link } from "react-router-dom";

import { useDocumentTitle } from "@/hooks/useDocumentTitle";

export function NotFoundPage() {
  useDocumentTitle("Page not found");
  return (
    <div className="mx-auto max-w-lg py-16 text-center">
      <h1 className="text-2xl">Page not found</h1>
      <p className="mt-3">
        <Link to="/products" className="underline">
          Back to shop
        </Link>
      </p>
    </div>
  );
}
