import { ProductListing } from "@/components/products/product-listing";
import { useDocumentTitle } from "@/hooks/useDocumentTitle";

export function ProductsPage() {
  useDocumentTitle("Shop");
  return (
    <ProductListing
      title="Shop"
      description="Search by name or category."
      basePath="/products"
    />
  );
}
