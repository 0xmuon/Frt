import { isRole } from "@/lib/roles";
/**
 * Turns shopping API JSON into the shapes the register, login, and catalog screens use.
 */
export function isRecord(value) {
    return typeof value === "object" && value !== null && !Array.isArray(value);
}
function pick(record, keys) {
    for (const key of keys) {
        const value = record[key];
        if (value !== undefined && value !== null && value !== "") {
            return value;
        }
    }
    return undefined;
}
function asString(value, fallback = "") {
    if (typeof value === "string")
        return value;
    if (typeof value === "number" && Number.isFinite(value))
        return String(value);
    return fallback;
}
function asNumber(value, fallback = 0) {
    if (typeof value === "number" && Number.isFinite(value))
        return value;
    if (typeof value === "string" && value.trim() && Number.isFinite(Number(value)))
        return Number(value);
    return fallback;
}
function asBoolean(value, fallback) {
    if (typeof value === "boolean")
        return value;
    if (value === "true" || value === 1 || value === "1")
        return true;
    if (value === "false" || value === 0 || value === "0")
        return false;
    return fallback;
}
export function asList(body, keys) {
    if (Array.isArray(body))
        return body;
    if (!isRecord(body))
        return [];
    for (const key of keys) {
        if (Array.isArray(body[key]))
            return body[key];
    }
    return [];
}
function slugify(value) {
    const slug = value
        .trim()
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, "-")
        .replace(/^-|-$/g, "");
    return slug || "shop";
}
export function errorText(body) {
    if (!isRecord(body))
        return null;
    if (typeof body.message === "string" && body.message.trim())
        return body.message;
    if (typeof body.detail === "string" && body.detail.trim())
        return body.detail;
    if (Array.isArray(body.detail)) {
        const first = body.detail.find(isRecord);
        if (first && typeof first.msg === "string") {
            const loc = Array.isArray(first.loc)
                ? first.loc.filter((part) => part !== "body" && part !== "query").map(String).join(" ")
                : "";
            return loc ? `${loc}: ${first.msg}` : first.msg;
        }
    }
    return null;
}
export function mapUser(value) {
    if (!isRecord(value))
        return null;
    const id = pick(value, ["user_id", "id", "UserID"]);
    const email = pick(value, ["email", "Email"]);
    if (id === undefined || email === undefined)
        return null;
    const roleText = asString(pick(value, ["role", "Role"]), "CUSTOMER").toUpperCase();
    const role = isRole(roleText) ? roleText : "CUSTOMER";
    return {
        id: asString(id),
        name: asString(pick(value, ["name", "full_name", "user_name", "Name", "FullName"]), "Shopper"),
        email: asString(email),
        role,
        isActive: asBoolean(pick(value, ["is_active", "isActive", "IsActive"]), true),
        mobile: asString(pick(value, ["mobile", "Mobile"])) || undefined,
        createdAt: asString(pick(value, ["created_at", "createdAt", "CreatedAt"]), new Date(0).toISOString()),
    };
}
export function mapToken(value) {
    if (typeof value === "string" && value.trim())
        return { access: value, refresh: null };
    if (!isRecord(value))
        return null;
    const nested = isRecord(value.token) ? value.token : value;
    const access = pick(nested, ["access_token", "token", "accessToken"]);
    if (typeof access !== "string" || !access.trim())
        return null;
    const refresh = pick(nested, ["refresh_token", "refreshToken"]);
    return { access, refresh: typeof refresh === "string" && refresh.trim() ? refresh : null };
}
export function mapProduct(value, options) {
    if (!isRecord(value))
        return null;
    const id = pick(value, ["product_id", "id", "ProductID"]);
    if (id === undefined)
        return null;
    const title = asString(pick(value, ["product_name", "name", "title", "ProductName"]), `Product ${asString(id)}`);
    const category = asString(pick(value, ["category_name", "category", "CategoryName", "category_slug"]), "shop");
    const image = asString(pick(value, ["image", "image_url", "Image"]));
    const active = asBoolean(pick(value, ["is_active", "isActive", "IsActive"]), true);
    if (!active && !options?.keepInactive)
        return null;
    return {
        id: asNumber(id),
        title,
        description: asString(pick(value, ["description", "Description"]), "No description yet."),
        category: category.includes(" ") ? slugify(category) : slugify(category),
        price: asNumber(pick(value, ["price", "Price"])),
        compareAtPrice: null,
        rating: asNumber(pick(value, ["rating", "Rating"])),
        reviewCount: asNumber(pick(value, ["review_count", "reviewCount"])),
        stock: asNumber(pick(value, ["available_quantity", "stock", "AvailableQuantity"])),
        brand: asString(pick(value, ["brand", "Brand"])),
        image,
        isNewArrival: asBoolean(pick(value, ["is_new_arrival", "isNewArrival"]), false),
        sku: asString(pick(value, ["sku", "SKU"])) || undefined,
    };
}
export function mapCategory(value, products) {
    if (!isRecord(value))
        return null;
    const name = asString(pick(value, ["category_name", "name", "Name"]));
    if (!name)
        return null;
    const slug = slugify(asString(pick(value, ["slug", "category_slug"]), name));
    const counted = products.filter((product) => product.category === slug || product.category === slugify(name));
    return {
        slug,
        name,
        count: asNumber(pick(value, ["count", "product_count"]), counted.length),
        image: asString(pick(value, ["image", "image_url"]), counted[0]?.image ?? ""),
    };
}
