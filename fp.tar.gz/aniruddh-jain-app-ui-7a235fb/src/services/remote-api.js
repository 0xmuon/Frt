import { filterProducts, listCategories as groupCategories } from "@/lib/catalog";
import { ApiError } from "@/services/api-error";
import { asList, errorText, isRecord, mapCategory, mapProduct, mapToken, mapUser } from "@/services/backend-map";
import { clearToken, readRefresh, readToken, saveRefresh, saveToken } from "@/services/session";
/**
 * Client for the shopping API on port 8000.
 * Register, login, and the product catalog. Role is never sent on register.
 */
/** Shopping API. Override with VITE_API_BASE_URL when it is not on this port. */
export function apiBaseUrl() {
    const configured = import.meta.env.VITE_API_BASE_URL?.trim();
    return (configured || "http://localhost:8000").replace(/\/$/, "");
}
function baseUrl() {
    return apiBaseUrl();
}
async function request(path, init) {
    const token = readToken();
    const headers = new Headers(init?.headers);
    const skipRefresh = init?.skipRefresh ?? false;
    headers.set("Accept", "application/json");
    if (init?.body) {
        headers.set("Content-Type", "application/json");
    }
    if (token) {
        headers.set("Authorization", `Bearer ${token}`);
    }
    let response;
    try {
        response = await fetch(`${baseUrl()}${path}`, {
            method: init?.method,
            body: init?.body,
            headers,
        });
    }
    catch {
        throw new ApiError(`The shopping API at ${baseUrl()} did not answer.`, 0);
    }
    if (response.status === 401 && !skipRefresh && readRefresh() && !path.startsWith("/api/auth/")) {
        const refreshed = await refreshAccess();
        if (refreshed) {
            return request(path, { ...init, skipRefresh: true });
        }
    }
    if (!response.ok) {
        let message = "Something went wrong. Please try again.";
        try {
            const body = await response.json();
            message = errorText(body) ?? message;
        }
        catch {
            // Keep the fallback when the body is not JSON.
        }
        if (response.status === 401) {
            clearToken();
        }
        throw new ApiError(message, response.status);
    }
    if (response.status === 204) {
        return null;
    }
    const text = await response.text();
    if (!text)
        return null;
    try {
        return JSON.parse(text);
    }
    catch {
        return text;
    }
}
async function refreshAccess() {
    const refresh = readRefresh();
    if (!refresh)
        return false;
    try {
        const response = await fetch(`${baseUrl()}/api/auth/refresh`, {
            method: "POST",
            headers: { Accept: "application/json", "Content-Type": "application/json" },
            body: JSON.stringify({ refresh_token: refresh }),
        });
        if (!response.ok) {
            clearToken();
            return false;
        }
        const body = await response.json();
        const tokens = mapToken(body);
        if (!tokens) {
            clearToken();
            return false;
        }
        saveToken(tokens.access);
        if (tokens.refresh)
            saveRefresh(tokens.refresh);
        return true;
    }
    catch {
        clearToken();
        return false;
    }
}
function remember(tokens) {
    saveToken(tokens.access);
    if (tokens.refresh)
        saveRefresh(tokens.refresh);
}
async function sessionFrom(body, fallback) {
    const tokens = mapToken(body);
    const embedded = mapUser(body) ?? (isRecord(body) ? mapUser(body.user) : null);
    if (tokens) {
        remember(tokens);
        const user = embedded ?? (await currentUser());
        return { token: tokens.access, user };
    }
    if (fallback) {
        return login(fallback);
    }
    throw new ApiError("The account was created, but no session token came back.", 502);
}
export async function register(input) {
    const body = await request("/api/users/register", {
        method: "POST",
        body: JSON.stringify({
            name: input.name,
            email: input.email,
            password: input.password,
            mobile: input.mobile,
        }),
    });
    return sessionFrom(body, input);
}
export async function login(input) {
    const body = await request("/api/auth/login", {
        method: "POST",
        body: JSON.stringify({ email: input.email, password: input.password }),
    });
    return sessionFrom(body);
}
export async function currentUser() {
    const body = await request("/api/auth/me");
    const user = mapUser(body) ?? (isRecord(body) ? mapUser(body.user) : null);
    if (!user) {
        throw new ApiError("Sign in to continue.", 401);
    }
    return user;
}
export async function logout() {
    try {
        await request("/api/auth/logout", { method: "POST", skipRefresh: true });
    }
    catch {
        // Logout still forgets the local tokens when the route is absent.
    }
    finally {
        clearToken();
    }
}
export async function listProducts(query = {}) {
    const body = await request("/api/products");
    const products = asList(body, ["products", "items"]).map((item) => mapProduct(item)).filter((item) => item !== null);
    return filterProducts(products, query);
}
export async function getProduct(id) {
    const body = await request(`/api/products/${id}`);
    const product = mapProduct(body) ?? (isRecord(body) ? mapProduct(body.product) : null);
    if (!product) {
        throw new ApiError("We couldn't find that product.", 404);
    }
    return product;
}
export async function listCategories() {
    const products = await listProducts();
    try {
        const body = await request("/api/categories");
        const categories = asList(body, ["categories", "items"])
            .map((item) => mapCategory(item, products))
            .filter((item) => item !== null);
        if (categories.length > 0)
            return categories;
    }
    catch {
        // The shop can still group the products it already loaded.
    }
    return groupCategories(products);
}
