import * as remote from "@/services/remote-api";

/** The UI talks only to this module. Account and catalog calls go to the shopping API. */
export const shopApi = {
    register: remote.register,
    login: remote.login,
    currentUser: remote.currentUser,
    logout: remote.logout,
    listProducts: remote.listProducts,
    getProduct: remote.getProduct,
    listCategories: remote.listCategories,
};
